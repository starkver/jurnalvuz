import React, { useState } from 'react';

interface User {
  id: number;
  name: string;
  email: string;
  userType: string;
  course?: string;
  groupNumber?: string;
  avatar: string;
}

interface StudentDashboardProps {
  user: User;
}

const StudentDashboard: React.FC<StudentDashboardProps> = ({ user }) => {
  const [activeTab, setActiveTab] = useState('overview');

  const assignments = [
    {
      id: 1,
      title: 'Математический анализ - Интегралы',
      subject: 'Математика',
      dueDate: '2024-12-15',
      status: 'pending',
      progress: 0,
      priority: 'high'
    },
    {
      id: 2,
      title: 'Лабораторная работа №3',
      subject: 'Физика',
      dueDate: '2024-12-20',
      status: 'in-progress',
      progress: 60,
      priority: 'medium'
    },
    {
      id: 3,
      title: 'Курсовой проект',
      subject: 'Информатика',
      dueDate: '2024-12-25',
      status: 'completed',
      progress: 100,
      priority: 'high'
    },
    {
      id: 4,
      title: 'Эссе на английском языке',
      subject: 'Английский язык',
      dueDate: '2025-01-10',
      status: 'pending',
      progress: 0,
      priority: 'low'
    }
  ];

  const courses = [
    {
      id: 1,
      name: 'Математический анализ',
      progress: 85,
      grade: 4.5,
      credits: 4,
      teacher: 'Иванов И.И.',
      nextClass: '2024-12-10 09:00'
    },
    {
      id: 2,
      name: 'Физика',
      progress: 72,
      grade: 4.2,
      credits: 3,
      teacher: 'Петрова А.С.',
      nextClass: '2024-12-10 11:00'
    },
    {
      id: 3,
      name: 'Информатика',
      progress: 91,
      grade: 4.8,
      credits: 4,
      teacher: 'Сидоров П.П.',
      nextClass: '2024-12-10 14:00'
    },
    {
      id: 4,
      name: 'Английский язык',
      progress: 78,
      grade: 4.0,
      credits: 2,
      teacher: 'Brown M.J.',
      nextClass: '2024-12-11 09:00'
    }
  ];

  const achievements = [
    {
      id: 1,
      title: 'Отличник семестра',
      description: 'Средний балл выше 4.5',
      date: '2024-11-01',
      icon: '🏆',
      color: 'yellow'
    },
    {
      id: 2,
      title: 'Активный участник',
      description: 'Участие в 5+ мероприятиях',
      date: '2024-10-15',
      icon: '⭐',
      color: 'blue'
    },
    {
      id: 3,
      title: 'Ранняя сдача',
      description: 'Сдача всех работ до дедлайна',
      date: '2024-09-20',
      icon: '🎯',
      color: 'green'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300';
      case 'pending':
        return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Сдано';
      case 'in-progress':
        return 'В работе';
      case 'pending':
        return 'Ожидает';
      default:
        return status;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'border-red-500';
      case 'medium':
        return 'border-yellow-500';
      case 'low':
        return 'border-green-500';
      default:
        return 'border-gray-300';
    }
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 rounded-lg">
        <h2 className="text-2xl font-bold mb-2">Добро пожаловать, {user.name}!</h2>
        <p className="text-blue-100 mb-4">
          Группа: {user.groupNumber} • Текущий семестр: Зимний 2024
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white bg-opacity-20 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold">4.5</div>
            <div className="text-sm opacity-80">Средний балл</div>
          </div>
          <div className="bg-white bg-opacity-20 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold">82%</div>
            <div className="text-sm opacity-80">Прогресс</div>
          </div>
          <div className="bg-white bg-opacity-20 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold">3</div>
            <div className="text-sm opacity-80">Активных заданий</div>
          </div>
          <div className="bg-white bg-opacity-20 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold">Ранг 2</div>
            <div className="text-sm opacity-80">В группе</div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow text-left">
          <div className="text-2xl mb-2">📚</div>
          <h3 className="font-medium text-gray-900 dark:text-white">Материалы курса</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">Лекции и конспекты</p>
        </button>
        <button className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow text-left">
          <div className="text-2xl mb-2">📝</div>
          <h3 className="font-medium text-gray-900 dark:text-white">Сдать задание</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">Загрузить работу</p>
        </button>
        <button className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow text-left">
          <div className="text-2xl mb-2">📊</div>
          <h3 className="font-medium text-gray-900 dark:text-white">Расписание</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">Ближайшие занятия</p>
        </button>
      </div>

      {/* Urgent Assignments */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Срочные задания</h3>
        <div className="space-y-3">
          {assignments.filter(a => a.status !== 'completed').slice(0, 3).map((assignment) => (
            <div key={assignment.id} className={`p-3 border-l-4 ${getPriorityColor(assignment.priority)} bg-gray-50 dark:bg-gray-700 rounded-r-lg`}>
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white">{assignment.title}</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">{assignment.subject}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">До: {assignment.dueDate}</p>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(assignment.status)}`}>
                  {getStatusText(assignment.status)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Calendar Preview */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Ближайшие занятия</h3>
        <div className="space-y-3">
          {courses.slice(0, 3).map((course) => (
            <div key={course.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">{course.name}</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">{course.teacher}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900 dark:text-white">{course.nextClass}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Ауд. 201</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCourses = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Мои курсы</h2>
        <div className="flex space-x-2">
          <button className="px-4 py-2 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-lg text-sm">
            Все курсы
          </button>
          <button className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg text-sm">
            Архив
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {courses.map((course) => (
          <div key={course.id} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">{course.name}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">{course.teacher}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{course.credits} зачетных единиц</p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{course.grade}</div>
                <div className="text-xs text-gray-500 dark:text-gray-400">Оценка</div>
              </div>
            </div>

            <div className="mb-4">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-gray-600 dark:text-gray-300">Прогресс</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">{course.progress}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-blue-600 dark:bg-blue-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${course.progress}%` }}
                />
              </div>
            </div>

            <div className="flex justify-between items-center">
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Следующее занятие: {course.nextClass}
              </div>
              <div className="flex space-x-2">
                <button className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 text-sm">
                  Материалы
                </button>
                <button className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 text-sm">
                  Задания
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAssignments = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Задания</h2>
        <div className="flex space-x-2">
          <select className="px-4 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-sm">
            <option>Все статусы</option>
            <option>Ожидает</option>
            <option>В работе</option>
            <option>Сдано</option>
          </select>
          <select className="px-4 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-sm">
            <option>Все предметы</option>
            <option>Математика</option>
            <option>Физика</option>
            <option>Информатика</option>
          </select>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Задание
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Предмет
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Дедлайн
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Статус
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Прогресс
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Действия
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {assignments.map((assignment) => (
                <tr key={assignment.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {assignment.title}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                    {assignment.subject}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                    {assignment.dueDate}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(assignment.status)}`}>
                      {getStatusText(assignment.status)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-16 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mr-2">
                        <div 
                          className="bg-blue-600 dark:bg-blue-500 h-2 rounded-full"
                          style={{ width: `${assignment.progress}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600 dark:text-gray-300">{assignment.progress}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {assignment.status === 'completed' ? (
                      <button className="text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300">
                        Просмотр
                      </button>
                    ) : (
                      <button className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300">
                        Сдать работу
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderAchievements = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Достижения</h2>
        <div className="text-sm text-gray-600 dark:text-gray-300">
          Уровень: Активный студент • До следующего уровня: 150 XP
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">Прогресс уровня</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300">850 / 1000 XP</p>
          </div>
          <div className="text-3xl">🎯</div>
        </div>
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
          <div className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full" style={{ width: '85%' }} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {achievements.map((achievement) => (
          <div key={achievement.id} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
            <div className="text-center">
              <div className="text-4xl mb-3">{achievement.icon}</div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                {achievement.title}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                {achievement.description}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Получено: {achievement.date}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Статистика семестра</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">23</div>
            <div className="text-sm text-gray-600 dark:text-gray-300">Сданных работ</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600 dark:text-green-400">18</div>
            <div className="text-sm text-gray-600 dark:text-gray-300">Вовремя</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">95%</div>
            <div className="text-sm text-gray-600 dark:text-gray-300">Посещаемость</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">5</div>
            <div className="text-sm text-gray-600 dark:text-gray-300">Достижений</div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
      {/* Navigation Tabs */}
      <div className="border-b border-gray-200 dark:border-gray-700 mb-6">
        <nav className="flex space-x-8">
          {[
            { id: 'overview', name: 'Обзор', icon: '📊' },
            { id: 'courses', name: 'Курсы', icon: '📚' },
            { id: 'assignments', name: 'Задания', icon: '📝' },
            { id: 'achievements', name: 'Достижения', icon: '🏆' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-gray-200 hover:border-gray-300 dark:hover:border-gray-600'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.name}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && renderOverview()}
      {activeTab === 'courses' && renderCourses()}
      {activeTab === 'assignments' && renderAssignments()}
      {activeTab === 'achievements' && renderAchievements()}
    </div>
  );
};

export default StudentDashboard;