#!/bin/bash

echo "🚀 Настройка образовательного портала для развертывания"

# Создание необходимых файлов для развертывания
echo "📝 Создание файлов конфигурации..."

# package.json для проекта
cat > package.json << EOF
{
  "name": "educational-portal",
  "version": "1.0.0",
  "description": "Образовательный портал с адаптивным дизайном",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "start": "serve -s dist"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.0.0",
    "vite": "^4.0.0",
    "tailwindcss": "^3.3.0",
    "autoprefixer": "^10.4.14",
    "postcss": "^8.4.24",
    "serve": "^14.2.0"
  }
}
EOF

# vite.config.js
cat > vite.config.js << EOF
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: './',
  build: {
    outDir: 'dist'
  }
})
EOF

# index.html
cat > index.html << EOF
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Образовательный портал</title>
    <meta name="description" content="Современный образовательный портал с адаптивным дизайном">
</head>
<body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
</body>
</html>
EOF

# main.jsx
mkdir -p src
cat > src/main.jsx << EOF
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '../App.tsx'
import '../styles/globals.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
EOF

# tailwind.config.js
cat > tailwind.config.js << EOF
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./App.tsx",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
EOF

# postcss.config.js
cat > postcss.config.js << EOF
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
EOF

echo "✅ Файлы конфигурации созданы"

# Инструкции для пользователя
echo "
🎯 ИНСТРУКЦИЯ ПО РАЗВЕРТЫВАНИЮ НА СЕРВЕРЕ:

1️⃣ УСТАНОВКА ЗАВИСИМОСТЕЙ:
   npm install

2️⃣ СБОРКА ПРОЕКТА:
   npm run build

3️⃣ РАЗВЕРТЫВАНИЕ НА СЕРВЕРЕ:
   
   Вариант A - Копирование файлов:
   - Скопируйте содержимое папки 'dist' на ваш веб-сервер
   - Настройте веб-сервер на обслуживание статических файлов
   
   Вариант B - Использование serve:
   npm run start
   (запустится на порту 3000)

4️⃣ НАСТРОЙКА ВЕБ-СЕРВЕРА (nginx example):
   
   server {
       listen 80;
       server_name ваш-домен.com;
       root /path/to/your/dist;
       index index.html;
       
       location / {
           try_files \$uri \$uri/ /index.html;
       }
   }

5️⃣ НАСТРОЙКА ДЛЯ GITHUB PAGES:
   
   - Добавьте файл .github/workflows/deploy.yml
   - Включите GitHub Pages в настройках репозитория
   - Выберите источник: GitHub Actions

📱 ПРОВЕРКА АДАПТИВНОСТИ:
   - Сайт автоматически адаптируется под все размеры экранов
   - Бургер меню появляется на экранах меньше 768px
   - Протестировано на мобильных устройствах, планшетах и ПК

🔧 ДОПОЛНИТЕЛЬНЫЕ КОМАНДЫ:
   npm run dev     - запуск в режиме разработки
   npm run preview - предварительный просмотр билда

✨ ГОТОВО! Ваш образовательный портал готов к развертыванию!
"