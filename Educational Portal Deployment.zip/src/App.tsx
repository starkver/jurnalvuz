import React, { useState, useEffect } from 'react';
import EnhancedAuthModal from './components/EnhancedAuthModal';
import UserProfile from './components/UserProfile';
import ThemeToggle from './components/ThemeToggle';
import StudentDashboard from './components/StudentDashboard';
import TeacherDashboard from './components/TeacherDashboard';
import AdminDashboard from './components/AdminDashboard';

interface User {
  id: number;
  name: string;
  firstName?: string;
  lastName?: string;
  middleName?: string;
  email: string;
  userType: string;
  course?: string;
  groupNumber?: string;
  department?: string;
  institution?: string;
  avatar: string;
}

const App = () => {
  const [activeSection, setActiveSection] = useState('main');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Загрузка сохраненных настроек при запуске
  useEffect(() => {
    // Восстановление темы
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    }

    // Восстановление пользователя
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        console.error('Ошибка при восстановлении пользователя:', error);
        localStorage.removeItem('user');
      }
    }
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const navigateTo = (section: string) => {
    setActiveSection(section);
    setIsMenuOpen(false);
  };

  const toggleTheme = () => {
    const newIsDarkMode = !isDarkMode;
    setIsDarkMode(newIsDarkMode);
    
    if (newIsDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  const handleLogin = (userData: User) => {
    setUser(userData);
    setIsAuthModalOpen(false);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
    setActiveSection('main');
  };

  const renderContent = () => {
    // If user is logged in, show their respective dashboard
    if (user) {
      switch (user.userType) {
        case 'student':
          return <StudentDashboard user={user} />;
        case 'teacher':
          return <TeacherDashboard user={user} />;
        case 'admin':
          return <AdminDashboard user={user} />;
        default:
          return <StudentDashboard user={user} />;
      }
    }

    // If no user, show public content based on section
    switch (activeSection) {
      case 'main':
        return (
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8 rounded-lg">
              <h1 className="mb-4">Добро пожаловать в образовательный портал</h1>
              <p className="text-lg opacity-90">
                Современная платформа для обучения с поддержкой всех типов пользователей
              </p>
              <div className="mt-6">
                <button
                  onClick={() => setIsAuthModalOpen(true)}
                  className="bg-white text-blue-600 px-6 py-3 rounded-lg font-medium hover:bg-blue-50 transition-colors mr-4"
                >
                  Начать обучение
                </button>
                <button className="border border-white text-white px-6 py-3 rounded-lg font-medium hover:bg-white hover:bg-opacity-10 transition-colors">
                  Узнать больше
                </button>
              </div>
            </div>

            {/* Role-based features showcase */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 text-center">
                <div className="text-4xl mb-4">👨‍🎓</div>
                <h3 className="mb-2 text-gray-900 dark:text-white">Для студентов</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">Полный доступ к курсам, заданиям и отслеживанию прогресса</p>
                <ul className="text-sm text-gray-500 dark:text-gray-400 space-y-1">
                  <li>• Интерактивные курсы</li>
                  <li>• Система достижений</li>
                  <li>• Персональная статистика</li>
                </ul>
              </div>
              
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 text-center">
                <div className="text-4xl mb-4">👨‍🏫</div>
                <h3 className="mb-2 text-gray-900 dark:text-white">Для преподавателей</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">Инструменты для создания и управления учебным процессом</p>
                <ul className="text-sm text-gray-500 dark:text-gray-400 space-y-1">
                  <li>• Создание материалов</li>
                  <li>• Система оценивания</li>
                  <li>• Аналитика успеваемости</li>
                </ul>
              </div>
              
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 text-center">
                <div className="text-4xl mb-4">⚙️</div>
                <h3 className="mb-2 text-gray-900 dark:text-white">Для администраторов</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">Полное управление платформой и пользователями</p>
                <ul className="text-sm text-gray-500 dark:text-gray-400 space-y-1">
                  <li>• Управление пользователями</li>
                  <li>• Системная аналитика</li>
                  <li>• Безопасность</li>
                </ul>
              </div>
            </div>

            {/* Features */}
            <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">
                Возможности платформы
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-3xl mb-3">🔐</div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">Безопасность</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Надежная система аутентификации и защиты данных</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl mb-3">📱</div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">Адаптивность</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Работает на всех устройствах и платформах</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl mb-3">🌙</div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">Темная тема</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Комфортная работа в любое время суток</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl mb-3">⚡</div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">Быстродействие</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Оптимизированный интерфейс для быстрой работы</p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-400 dark:border-blue-500 p-6">
              <h3 className="text-blue-800 dark:text-blue-300 mb-4 text-lg font-medium">Начните прямо сейчас</h3>
              <p className="text-blue-700 dark:text-blue-200 mb-4">
                Зарегистрируйтесь и получите полный доступ ко всем возможностям образовательной платформы
              </p>
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
              >
                Создать аккаунт
              </button>
            </div>
          </div>
        );



      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 transition-colors">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <span className="text-white text-sm font-bold">ОП</span>
                </div>
                <h1 className="text-xl text-gray-900 dark:text-white">Образовательный портал</h1>
              </div>
            </div>

            {/* Desktop Navigation - only show for non-authenticated users */}
            {!user && (
              <nav className="hidden md:flex items-center space-x-6">
                <div className="flex space-x-4">
                  <button
                    onClick={() => navigateTo('main')}
                    className={`px-3 py-2 rounded-md text-sm transition-colors ${
                      activeSection === 'main'
                        ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                        : 'text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    О платформе
                  </button>
                  <button className="px-3 py-2 rounded-md text-sm text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700">
                    Возможности
                  </button>
                  <button className="px-3 py-2 rounded-md text-sm text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700">
                    Контакты
                  </button>
                </div>
              </nav>
            )}

            {/* User Navigation - show for authenticated users */}
            {user && (
              <nav className="hidden md:flex items-center space-x-6">
                <div className="text-sm text-gray-600 dark:text-gray-300">
                  Добро пожаловать, {user.name}
                </div>
              </nav>
            )}

            <div className="flex items-center space-x-3">
              <ThemeToggle isDark={isDarkMode} onToggle={toggleTheme} />
              
              {user ? (
                <UserProfile user={user} onLogout={handleLogout} />
              ) : (
                <button
                  onClick={() => setIsAuthModalOpen(true)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors text-sm"
                >
                  Войти
                </button>
              )}

              {/* Mobile menu button */}
              <button
                onClick={toggleMenu}
                className="md:hidden inline-flex items-center justify-center p-2 rounded-md text-gray-400 dark:text-gray-300 hover:text-gray-500 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
              >
                <span className="sr-only">Открыть меню</span>
                <svg
                  className={`${isMenuOpen ? 'hidden' : 'block'} h-6 w-6`}
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                <svg
                  className={`${isMenuOpen ? 'block' : 'hidden'} h-6 w-6`}
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>

          {/* Mobile menu - only for non-authenticated users */}
          {!user && (
            <div className={`md:hidden ${isMenuOpen ? 'block' : 'hidden'}`}>
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-gray-50 dark:bg-gray-700">
                <button
                  onClick={() => navigateTo('main')}
                  className={`block px-3 py-2 rounded-md text-base w-full text-left transition-colors ${
                    activeSection === 'main'
                      ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                      : 'text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600'
                  }`}
                >
                  О платформе
                </button>
                <button className="block px-3 py-2 rounded-md text-base w-full text-left text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600">
                  Возможности
                </button>
                <button className="block px-3 py-2 rounded-md text-base w-full text-left text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600">
                  Контакты
                </button>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          {renderContent()}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 mt-12">
        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
          <div className="text-center text-sm text-gray-500 dark:text-gray-400">
            <p>&copy; 2024 Образовательный портал. Все права защищены.</p>
            <p className="mt-2">Разработано для удобного обучения</p>
          </div>
        </div>
      </footer>

      {/* Enhanced Auth Modal */}
      <EnhancedAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
      />
    </div>
  );
};

export default App;