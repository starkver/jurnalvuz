import React, { useState, useMemo } from 'react';

interface FAQItem {
  id: number;
  question: string;
  answer: string;
  category: string;
}

const FAQPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [openItems, setOpenItems] = useState<number[]>([]);
  const [isQuestionModalOpen, setIsQuestionModalOpen] = useState(false);
  const [questionForm, setQuestionForm] = useState({
    category: '',
    question: '',
    contact: ''
  });

  const categories = [
    { id: 'all', name: 'Все вопросы', icon: '📋' },
    { id: 'registration', name: 'Регистрация', icon: '✍️' },
    { id: 'learning', name: 'Учебный процесс', icon: '📚' },
    { id: 'technical', name: 'Технические вопросы', icon: '⚙️' },
    { id: 'payment', name: 'Оплата', icon: '💳' },
    { id: 'other', name: 'Другое', icon: '❓' }
  ];

  const faqItems: FAQItem[] = [
    {
      id: 1,
      question: 'Как зарегистрироваться на платформе?',
      answer: 'Для регистрации нажмите кнопку "Войти" в правом верхнем углу, затем выберите "Зарегистрироваться". Заполните форму, указав ваше ФИО (Фамилия, Имя, Отчество), выберите тип аккаунта (студент, преподаватель или администратор), укажите учебное заведение и создайте надежный пароль. После заполнения всех полей нажмите "Зарегистрироваться".',
      category: 'registration'
    },
    {
      id: 2,
      question: 'Какие требования к паролю?',
      answer: 'Пароль должен содержать минимум 8 символов, включая заглавные и строчные буквы, цифры и специальные символы. Это необходимо для обеспечения безопасности вашего аккаунта.',
      category: 'registration'
    },
    {
      id: 3,
      question: 'Забыл пароль. Как восстановить доступ?',
      answer: 'На форме входа нажмите "Забыли пароль?". Введите ваше ФИО, и система отправит вам код восстановления. Введите этот код и создайте новый пароль.',
      category: 'registration'
    },
    {
      id: 4,
      question: 'Как получить доступ к курсам?',
      answer: 'После авторизации в системе вы автоматически получаете доступ к разделам "1 курс" и "2 курс" через главное меню. Курсы содержат лекции, лабораторные работы, тесты и учебные материалы.',
      category: 'learning'
    },
    {
      id: 5,
      question: 'Как сдать лабораторную работу?',
      answer: 'Перейдите в раздел нужного курса, выберите вкладку "Лабораторные". Найдите нужную работу и нажмите кнопку "Сдать работу". Загрузите файл с выполненным заданием и дождитесь проверки преподавателем.',
      category: 'learning'
    },
    {
      id: 6,
      question: 'Как отслеживать свой прогресс?',
      answer: 'В личном кабинете на главной странице отображается общая статистика: средний балл, процент выполнения заданий, активные задания. Также прогресс по каждому курсу можно просмотреть на соответствующих страницах курсов.',
      category: 'learning'
    },
    {
      id: 7,
      question: 'Что такое система достижений?',
      answer: 'Система достижений мотивирует студентов через игровые элементы. За выполнение определенных задач вы получаете достижения. Они отображаются в разделе "2 курс". Нажмите на серую иконку достижения, чтобы посмотреть условия его получения.',
      category: 'learning'
    },
    {
      id: 8,
      question: 'Не открывается видео с лекцией',
      answer: 'Убедитесь, что у вас стабильное интернет-соединение. Попробуйте обновить страницу (F5). Проверьте, обновлен ли ваш браузер до последней версии. Если проблема сохраняется, очистите кеш браузера или попробуйте использовать другой браузер.',
      category: 'technical'
    },
    {
      id: 9,
      question: 'Сайт работает медленно',
      answer: 'Медленная работа может быть связана с интернет-соединением или большой загрузкой сервера. Попробуйте закрыть другие вкладки браузера, очистить кеш или зайти позже. Также убедитесь, что на вашем устройстве достаточно свободной памяти.',
      category: 'technical'
    },
    {
      id: 10,
      question: 'Не работает темная тема',
      answer: 'Нажмите на иконку переключения темы (🌙/☀️) в правом верхнем углу. Настройки темы сохраняются автоматически в локальном хранилище браузера. Если проблема сохраняется, очистите кеш браузера.',
      category: 'technical'
    },
    {
      id: 11,
      question: 'Как оплатить курсы?',
      answer: 'Базовые курсы доступны бесплатно для всех зарегистрированных пользователей. Для доступа к премиум-материалам свяжитесь с администрацией через форму обратной связи.',
      category: 'payment'
    },
    {
      id: 12,
      question: 'Есть ли пробный период?',
      answer: 'Да, все новые пользователи получают полный доступ ко всем материалам на 14 дней. После окончания пробного периода доступ сохраняется к базовым материалам.',
      category: 'payment'
    },
    {
      id: 13,
      question: 'Можно ли изменить тип аккаунта?',
      answer: 'Для изменения типа аккаунта (студент/преподаватель/администратор) обратитесь к системному администратору. Самостоятельно изменить тип аккаунта невозможно по соображениям безопасности.',
      category: 'other'
    },
    {
      id: 14,
      question: 'Как связаться с преподавателем?',
      answer: 'В каждом курсе есть информация о преподавателе. Вы можете отправить сообщение через внутреннюю систему сообщений платформы или использовать контактные данные, указанные в профиле преподавателя.',
      category: 'other'
    },
    {
      id: 15,
      question: 'Где посмотреть расписание занятий?',
      answer: 'Расписание занятий доступно в разделе "2 курс" или в личном кабинете студента. Там отображается полное расписание по дням недели с указанием времени, аудиторий и типов занятий.',
      category: 'other'
    }
  ];

  const filteredFAQs = useMemo(() => {
    let filtered = faqItems;

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(item => item.category === selectedCategory);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        item =>
          item.question.toLowerCase().includes(query) ||
          item.answer.toLowerCase().includes(query)
      );
    }

    return filtered;
  }, [selectedCategory, searchQuery]);

  const toggleItem = (id: number) => {
    setOpenItems(prev =>
      prev.includes(id) ? prev.filter(itemId => itemId !== id) : [...prev, id]
    );
  };

  const handleSubmitQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically send the question to your backend
    alert('Спасибо! Ваш вопрос отправлен. Мы ответим в ближайшее время.');
    setIsQuestionModalOpen(false);
    setQuestionForm({ category: '', question: '', contact: '' });
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-cyan-600 to-blue-600 text-white p-8 rounded-lg">
        <h1 className="mb-2">Часто задаваемые вопросы</h1>
        <p className="text-lg opacity-90">
          Найдите ответы на популярные вопросы о нашем учебном процессе
        </p>
      </div>

      {/* Search Bar */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Поиск по вопросам..."
            className="block w-full pl-10 pr-10 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>
      </div>

      {/* Categories */}
      <div className="flex flex-wrap gap-3">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
              selectedCategory === category.id
                ? 'bg-blue-600 text-white shadow-md scale-105'
                : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-600 hover:shadow-sm'
            }`}
          >
            <span>{category.icon}</span>
            <span>{category.name}</span>
          </button>
        ))}
      </div>

      {/* Results Count */}
      {(searchQuery || selectedCategory !== 'all') && (
        <div className="text-sm text-gray-600 dark:text-gray-400">
          Найдено <strong>{filteredFAQs.length}</strong> {filteredFAQs.length === 1 ? 'вопрос' : 'вопросов'}
        </div>
      )}

      {/* FAQ Accordion */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 divide-y divide-gray-200 dark:divide-gray-700">
        {filteredFAQs.length > 0 ? (
          filteredFAQs.map((item) => (
            <div key={item.id} className="transition-all duration-200">
              <button
                onClick={() => toggleItem(item.id)}
                className="w-full px-6 py-4 flex items-start justify-between hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors text-left"
              >
                <div className="flex-1 pr-4">
                  <h4 className="text-gray-900 dark:text-white">
                    {item.question}
                  </h4>
                </div>
                <div className="flex-shrink-0">
                  <svg
                    className={`w-5 h-5 text-gray-500 dark:text-gray-400 transition-transform duration-200 ${
                      openItems.includes(item.id) ? 'rotate-180' : ''
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </button>
              
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openItems.includes(item.id) ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-6 pb-4 text-gray-600 dark:text-gray-400">
                  {item.answer}
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="px-6 py-12 text-center">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-gray-900 dark:text-white mb-2">
              Ничего не найдено
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Попробуйте изменить поисковый запрос или выбрать другую категорию
            </p>
          </div>
        )}
      </div>

      {/* Ask Question Button */}
      <div className="bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-2 border-blue-200 dark:border-blue-800 rounded-lg p-6 text-center">
        <h3 className="text-gray-900 dark:text-white mb-2">
          Не нашли ответ на свой вопрос?
        </h3>
        <p className="text-gray-600 dark:text-gray-400 mb-4">
          Отправьте нам свой вопрос, и мы ответим в ближайшее время
        </p>
        <button
          onClick={() => setIsQuestionModalOpen(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-all duration-200 hover:scale-105 shadow-md"
        >
          Задать свой вопрос
        </button>
      </div>

      {/* Question Modal */}
      {isQuestionModalOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
          onClick={() => setIsQuestionModalOpen(false)}
        >
          <div
            className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-gray-900 dark:text-white">
                Задать вопрос
              </h3>
              <button
                onClick={() => setIsQuestionModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <form onSubmit={handleSubmitQuestion} className="space-y-4">
              <div>
                <label className="block text-gray-700 dark:text-gray-300 mb-2">
                  Категория вопроса
                </label>
                <select
                  value={questionForm.category}
                  onChange={(e) => setQuestionForm({ ...questionForm, category: e.target.value })}
                  required
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Выберите категорию</option>
                  {categories.filter(c => c.id !== 'all').map(category => (
                    <option key={category.id} value={category.id}>
                      {category.icon} {category.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-gray-700 dark:text-gray-300 mb-2">
                  Ваш вопрос
                </label>
                <textarea
                  value={questionForm.question}
                  onChange={(e) => setQuestionForm({ ...questionForm, question: e.target.value })}
                  required
                  rows={5}
                  placeholder="Опишите ваш вопрос максимально подробно..."
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              <div>
                <label className="block text-gray-700 dark:text-gray-300 mb-2">
                  Контактная информация (Email или Телефон)
                </label>
                <input
                  type="text"
                  value={questionForm.contact}
                  onChange={(e) => setQuestionForm({ ...questionForm, contact: e.target.value })}
                  required
                  placeholder="your@email.com или +7 (XXX) XXX-XX-XX"
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
                >
                  Отправить вопрос
                </button>
                <button
                  type="button"
                  onClick={() => setIsQuestionModalOpen(false)}
                  className="px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Отмена
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Additional Info */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-start gap-4">
          <div className="text-4xl">💡</div>
          <div>
            <h4 className="text-gray-900 dark:text-white mb-2">
              Полезная информация
            </h4>
            <p className="text-gray-600 dark:text-gray-400 mb-3">
              Большинство вопросов можно решить, обратившись к документации:
            </p>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                <span className="text-blue-600">→</span>
                <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                  Руководство пользователя
                </a>
              </li>
              <li className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                <span className="text-blue-600">→</span>
                <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                  Видеоинструкции
                </a>
              </li>
              <li className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                <span className="text-blue-600">→</span>
                <a href="#" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                  Техническая поддержка
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQPage;