import React, { useState } from 'react';

interface User {
  id: number;
  name: string;
  email: string;
  userType: string;
  department?: string;
  avatar: string;
}

interface TeacherDashboardProps {
  user: User;
}

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ user }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedCourse, setSelectedCourse] = useState(null);

  const courses = [
    {
      id: 1,
      name: 'Математический анализ',
      students: 25,
      pendingGrades: 8,
      avgGrade: 4.2,
      schedule: 'Пн, Ср 9:00-10:30',
      room: 'Ауд. 201'
    },
    {
      id: 2,
      name: 'Алгебра и геометрия',
      students: 30,
      pendingGrades: 12,
      avgGrade: 3.9,
      schedule: 'Вт, Чт 11:00-12:30',
      room: 'Ауд. 305'
    },
    {
      id: 3,
      name: 'Дискретная математика',
      students: 22,
      pendingGrades: 5,
      avgGrade: 4.1,
      schedule: 'Пт 14:00-17:00',
      room: 'Ауд. 102'
    }
  ];

  const assignments = [
    {
      id: 1,
      title: 'Контрольная работа №3',
      course: 'Математический анализ',
      dueDate: '2024-12-15',
      submitted: 18,
      total: 25,
      checked: 5,
      avgGrade: 4.3
    },
    {
      id: 2,
      title: 'Лабораторная работа №2',
      course: 'Дискретная математика',
      dueDate: '2024-12-20',
      submitted: 20,
      total: 22,
      checked: 15,
      avgGrade: 4.1
    },
    {
      id: 3,
      title: 'Домашнее задание №5',
      course: 'Алгебра и геометрия',
      dueDate: '2024-12-18',
      submitted: 25,
      total: 30,
      checked: 10,
      avgGrade: 3.8
    }
  ];

  const materials = [
    {
      id: 1,
      title: 'Лекция 15: Интегралы',
      course: 'Математический анализ',
      type: 'lecture',
      views: 23,
      uploadDate: '2024-12-05',
      size: '2.3 MB'
    },
    {
      id: 2,
      title: 'Практическое задание №8',
      course: 'Алгебра и геометрия',
      type: 'assignment',
      views: 28,
      uploadDate: '2024-12-03',
      size: '856 KB'
    },
    {
      id: 3,
      title: 'Дополнительные материалы',
      course: 'Дискретная математика',
      type: 'material',
      views: 15,
      uploadDate: '2024-12-01',
      size: '4.1 MB'
    }
  ];

  const students = [
    {
      id: 1,
      name: 'Иванов Иван',
      group: 'ИТ-101',
      avgGrade: 4.5,
      attendance: 95,
      lastActivity: '2024-12-09',
      assignments: { completed: 8, total: 10 }
    },
    {
      id: 2,
      name: 'Петрова Анна',
      group: 'ИТ-101',
      avgGrade: 4.8,
      attendance: 100,
      lastActivity: '2024-12-09',
      assignments: { completed: 10, total: 10 }
    },
    {
      id: 3,
      name: 'Сидоров Петр',
      group: 'ИТ-102',
      avgGrade: 3.7,
      attendance: 85,
      lastActivity: '2024-12-08',
      assignments: { completed: 6, total: 10 }
    }
  ];

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-6 rounded-lg">
        <h2 className="text-2xl font-bold mb-2">Добро пожаловать, {user.name}</h2>
        <p className="text-green-100 mb-4">
          Кафедра: {user.department || 'Математики'} • Преподаватель
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white bg-opacity-20 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold">{courses.length}</div>
            <div className="text-sm opacity-80">Курсов</div>
          </div>
          <div className="bg-white bg-opacity-20 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold">{courses.reduce((sum, c) => sum + c.students, 0)}</div>
            <div className="text-sm opacity-80">Студентов</div>
          </div>
          <div className="bg-white bg-opacity-20 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold">{assignments.reduce((sum, a) => sum + (a.total - a.checked), 0)}</div>
            <div className="text-sm opacity-80">Нужно проверить</div>
          </div>
          <div className="bg-white bg-opacity-20 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold">4.1</div>
            <div className="text-sm opacity-80">Средняя оценка</div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <button className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow text-left">
          <div className="text-2xl mb-2">📄</div>
          <h3 className="font-medium text-gray-900 dark:text-white">Добавить материал</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">Загрузить лекцию</p>
        </button>
        <button className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow text-left">
          <div className="text-2xl mb-2">📝</div>
          <h3 className="font-medium text-gray-900 dark:text-white">Создать задание</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">Новое задание</p>
        </button>
        <button className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow text-left">
          <div className="text-2xl mb-2">✅</div>
          <h3 className="font-medium text-gray-900 dark:text-white">Проверить работы</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">Оценить задания</p>
        </button>
        <button className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow text-left">
          <div className="text-2xl mb-2">📊</div>
          <h3 className="font-medium text-gray-900 dark:text-white">Статистика</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">Успеваемость</p>
        </button>
      </div>

      {/* My Courses */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Мои курсы</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {courses.map((course) => (
            <div key={course.id} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 dark:text-white mb-2">{course.name}</h4>
              <div className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <div className="flex justify-between">
                  <span>Студентов:</span>
                  <span>{course.students}</span>
                </div>
                <div className="flex justify-between">
                  <span>К проверке:</span>
                  <span className="text-orange-600 dark:text-orange-400">{course.pendingGrades}</span>
                </div>
                <div className="flex justify-between">
                  <span>Средняя оценка:</span>
                  <span className="text-green-600 dark:text-green-400">{course.avgGrade}</span>
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                  {course.schedule} • {course.room}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pending Reviews */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Требуют проверки</h3>
        <div className="space-y-3">
          {assignments.filter(a => a.checked < a.submitted).slice(0, 3).map((assignment) => (
            <div key={assignment.id} className="flex items-center justify-between p-3 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg">
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">{assignment.title}</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">{assignment.course}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Проверено: {assignment.checked} из {assignment.submitted}
                </p>
              </div>
              <button className="bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-300 px-4 py-2 rounded-lg text-sm hover:bg-orange-200 dark:hover:bg-orange-900/50">
                Проверить
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCourses = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Управление курсами</h2>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
          Создать курс
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {courses.map((course) => (
          <div key={course.id} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-medium text-gray-900 dark:text-white">{course.name}</h3>
                <p className="text-gray-600 dark:text-gray-300">{course.schedule} • {course.room}</p>
              </div>
              <div className="flex space-x-2">
                <button className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 text-sm">
                  Редактировать
                </button>
                <button className="text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300 text-sm">
                  Статистика
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="text-lg font-bold text-gray-900 dark:text-white">{course.students}</div>
                <div className="text-sm text-gray-600 dark:text-gray-300">Студентов</div>
              </div>
              <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="text-lg font-bold text-orange-600 dark:text-orange-400">{course.pendingGrades}</div>
                <div className="text-sm text-gray-600 dark:text-gray-300">К проверке</div>
              </div>
              <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="text-lg font-bold text-green-600 dark:text-green-400">{course.avgGrade}</div>
                <div className="text-sm text-gray-600 dark:text-gray-300">Средняя оценка</div>
              </div>
              <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="text-lg font-bold text-blue-600 dark:text-blue-400">90%</div>
                <div className="text-sm text-gray-600 dark:text-gray-300">Посещаемость</div>
              </div>
            </div>

            <div className="flex space-x-4">
              <button className="flex-1 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 py-2 px-4 rounded-lg text-sm hover:bg-blue-200 dark:hover:bg-blue-900/50">
                Материалы курса
              </button>
              <button className="flex-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 py-2 px-4 rounded-lg text-sm hover:bg-green-200 dark:hover:bg-green-900/50">
                Задания
              </button>
              <button className="flex-1 bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 py-2 px-4 rounded-lg text-sm hover:bg-purple-200 dark:hover:bg-purple-900/50">
                Студенты
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAssignments = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Задания и оценки</h2>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
          Создать задание
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Задание
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Курс
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Дедлайн
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Сдано
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Проверено
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Средняя оценка
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Действия
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {assignments.map((assignment) => (
                <tr key={assignment.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {assignment.title}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                    {assignment.course}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                    {assignment.dueDate}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                    {assignment.submitted}/{assignment.total}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-16 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mr-2">
                        <div 
                          className="bg-blue-600 dark:bg-blue-500 h-2 rounded-full"
                          style={{ width: `${(assignment.checked / assignment.submitted) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600 dark:text-gray-300">
                        {assignment.checked}/{assignment.submitted}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                    {assignment.avgGrade}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex space-x-2">
                      <button className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300">
                        Проверить
                      </button>
                      <button className="text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300">
                        Результаты
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderMaterials = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Учебные материалы</h2>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
          Добавить материал
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {materials.map((material) => (
          <div key={material.id} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <div className="text-2xl">
                {material.type === 'lecture' ? '📄' : material.type === 'assignment' ? '📝' : '📚'}
              </div>
              <div className="flex space-x-2">
                <button className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                  </svg>
                </button>
                <button className="text-gray-400 hover:text-red-600 dark:hover:text-red-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
            </div>

            <h3 className="font-medium text-gray-900 dark:text-white mb-2">{material.title}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">{material.course}</p>
            
            <div className="flex justify-between items-center text-sm text-gray-500 dark:text-gray-400 mb-4">
              <span>Просмотров: {material.views}</span>
              <span>{material.size}</span>
            </div>

            <div className="text-xs text-gray-500 dark:text-gray-400">
              Загружено: {material.uploadDate}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Загрузить новый материал</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Название материала
            </label>
            <input
              type="text"
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              placeholder="Введите название"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Курс
            </label>
            <select className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
              <option>Выберите курс</option>
              {courses.map((course) => (
                <option key={course.id} value={course.id}>{course.name}</option>
              ))}
            </select>
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Файл
            </label>
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center">
              <div className="text-4xl mb-4">📎</div>
              <p className="text-gray-600 dark:text-gray-300 mb-2">Перетащите файл сюда или</p>
              <button className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300">
                выберите файл
              </button>
            </div>
          </div>
        </div>
        <div className="mt-6 flex justify-end">
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg">
            Загрузить материал
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
      {/* Navigation Tabs */}
      <div className="border-b border-gray-200 dark:border-gray-700 mb-6">
        <nav className="flex space-x-8">
          {[
            { id: 'overview', name: 'Обзор', icon: '📊' },
            { id: 'courses', name: 'Курсы', icon: '📚' },
            { id: 'assignments', name: 'Задания', icon: '📝' },
            { id: 'materials', name: 'Материалы', icon: '📄' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-green-500 text-green-600 dark:text-green-400'
                  : 'border-transparent text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-gray-200 hover:border-gray-300 dark:hover:border-gray-600'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.name}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && renderOverview()}
      {activeTab === 'courses' && renderCourses()}
      {activeTab === 'assignments' && renderAssignments()}
      {activeTab === 'materials' && renderMaterials()}
    </div>
  );
};

export default TeacherDashboard;