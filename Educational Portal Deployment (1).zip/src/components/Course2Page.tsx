import React, { useState } from 'react';

const Course2Page = () => {
  const [achievements, setAchievements] = useState([
    { id: 1, title: 'Первый проект', icon: '🎯', unlocked: true, date: '15.01.2024' },
    { id: 2, title: 'Мастер тестов', icon: '🏆', unlocked: true, date: '22.01.2024' },
    { id: 3, title: 'Отличник', icon: '⭐', unlocked: false, date: null },
    { id: 4, title: 'Командный игрок', icon: '🤝', unlocked: false, date: null },
    { id: 5, title: 'Инноватор', icon: '💡', unlocked: false, date: null },
    { id: 6, title: 'Марафонец', icon: '🎓', unlocked: true, date: '10.02.2024' }
  ]);

  const [projects, setProjects] = useState([
    { 
      id: 1, 
      title: 'Веб-приложение "Задачник"', 
      description: 'Создание приложения для управления задачами',
      progress: 85, 
      deadline: '15.03.2024',
      status: 'in-progress',
      team: ['Вы', 'Иванов А.', 'Петрова М.']
    },
    { 
      id: 2, 
      title: 'Мобильное приложение', 
      description: 'Разработка приложения для Android',
      progress: 45, 
      deadline: '30.03.2024',
      status: 'in-progress',
      team: ['Вы', 'Сидоров П.']
    },
    { 
      id: 3, 
      title: 'Анализ данных', 
      description: 'Проект по машинному обучению',
      progress: 100, 
      deadline: '01.03.2024',
      status: 'completed',
      team: ['Вы']
    }
  ]);

  const skills = [
    { name: 'JavaScript', level: 85, color: 'bg-yellow-500' },
    { name: 'React', level: 70, color: 'bg-blue-500' },
    { name: 'Python', level: 90, color: 'bg-green-500' },
    { name: 'SQL', level: 65, color: 'bg-purple-500' },
    { name: 'Git', level: 75, color: 'bg-orange-500' }
  ];

  const schedule = [
    { day: 'Понедельник', classes: [
      { time: '09:00', subject: 'Веб-разработка', room: '301', type: 'lecture' },
      { time: '11:00', subject: 'Базы данных', room: '205', type: 'practice' }
    ]},
    { day: 'Вторник', classes: [
      { time: '10:00', subject: 'Алгоритмы', room: '102', type: 'lecture' }
    ]},
    { day: 'Среда', classes: [
      { time: '09:00', subject: 'Мобильная разработка', room: '401', type: 'practice' },
      { time: '13:00', subject: 'Проектная работа', room: '305', type: 'project' }
    ]},
    { day: 'Четверг', classes: [
      { time: '11:00', subject: 'Машинное обучение', room: '201', type: 'lecture' }
    ]},
    { day: 'Пятница', classes: [
      { time: '10:00', subject: 'Защита проектов', room: '501', type: 'presentation' }
    ]}
  ];

  const toggleAchievement = (id: number) => {
    setAchievements(prev => prev.map(ach => 
      ach.id === id && !ach.unlocked
        ? { ...ach, unlocked: true, date: new Date().toLocaleDateString('ru-RU') }
        : ach
    ));
  };

  const increaseProgress = (id: number) => {
    setProjects(prev => prev.map(proj => {
      if (proj.id === id && proj.progress < 100) {
        const newProgress = Math.min(proj.progress + 10, 100);
        return {
          ...proj,
          progress: newProgress,
          status: newProgress === 100 ? 'completed' : 'in-progress'
        };
      }
      return proj;
    }));
  };

  const getClassTypeIcon = (type: string) => {
    const icons = {
      lecture: '📚',
      practice: '💻',
      project: '🚀',
      presentation: '🎤'
    };
    return icons[type as keyof typeof icons] || '📖';
  };

  const getClassTypeColor = (type: string) => {
    const colors = {
      lecture: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
      practice: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
      project: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400',
      presentation: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400'
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-6 rounded-lg">
        <h1 className="mb-2">2 курс</h1>
        <p className="text-lg opacity-90">Продвинутая разработка и проектная деятельность</p>
        <div className="mt-4 flex flex-wrap gap-4">
          <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
            <div className="text-sm opacity-80">Завершено проектов</div>
            <div className="text-2xl">1/3</div>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
            <div className="text-sm opacity-80">Достижений</div>
            <div className="text-2xl">{achievements.filter(a => a.unlocked).length}/{achievements.length}</div>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
            <div className="text-sm opacity-80">Рейтинг в группе</div>
            <div className="text-2xl">3/25</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Projects */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <h3 className="text-gray-900 dark:text-white mb-4">Проектные работы</h3>
            <div className="space-y-4">
              {projects.map((project) => (
                <div
                  key={project.id}
                  className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:shadow-md transition-all duration-200"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="text-gray-900 dark:text-white">{project.title}</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{project.description}</p>
                      <div className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                        Дедлайн: {project.deadline}
                      </div>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-xs ${
                      project.status === 'completed'
                        ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                        : 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400'
                    }`}>
                      {project.status === 'completed' ? 'Завершено' : 'В процессе'}
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Прогресс</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">{project.progress}%</span>
                    </div>
                    <div 
                      className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 cursor-pointer overflow-hidden"
                      onClick={() => increaseProgress(project.id)}
                    >
                      <div
                        className="h-2.5 rounded-full transition-all duration-500 bg-gradient-to-r from-blue-500 to-purple-500"
                        style={{ width: `${project.progress}%` }}
                      ></div>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      Нажмите на прогресс-бар, чтобы обновить
                    </p>
                  </div>

                  {/* Team */}
                  <div className="mt-3">
                    <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">Команда:</div>
                    <div className="flex flex-wrap gap-2">
                      {project.team.map((member, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-full text-sm"
                        >
                          {member}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-4 flex gap-2">
                    <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all duration-200 hover:scale-95">
                      Открыть проект
                    </button>
                    {project.status !== 'completed' && (
                      <button className="border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-all duration-200">
                        Обновить статус
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Schedule */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <h3 className="text-gray-900 dark:text-white mb-4">Расписание занятий</h3>
            <div className="space-y-4">
              {schedule.map((day, idx) => (
                <div key={idx} className="border-l-4 border-blue-500 pl-4">
                  <h4 className="text-gray-900 dark:text-white mb-2">{day.day}</h4>
                  <div className="space-y-2">
                    {day.classes.map((cls, clsIdx) => (
                      <div
                        key={clsIdx}
                        className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-all duration-200 cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <div className="text-2xl">{getClassTypeIcon(cls.type)}</div>
                          <div>
                            <div className="text-gray-900 dark:text-white">{cls.subject}</div>
                            <div className="text-sm text-gray-600 dark:text-gray-400">
                              {cls.time} · Аудитория {cls.room}
                            </div>
                          </div>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs ${getClassTypeColor(cls.type)}`}>
                          {cls.type === 'lecture' ? 'Лекция' : cls.type === 'practice' ? 'Практика' : cls.type === 'project' ? 'Проект' : 'Презентация'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Achievements */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <h3 className="text-gray-900 dark:text-white mb-4">Достижения</h3>
            <div className="grid grid-cols-3 gap-3">
              {achievements.map((achievement) => (
                <div
                  key={achievement.id}
                  onClick={() => toggleAchievement(achievement.id)}
                  className={`aspect-square flex flex-col items-center justify-center p-3 rounded-lg cursor-pointer transition-all duration-200 ${
                    achievement.unlocked
                      ? 'bg-gradient-to-br from-yellow-100 to-orange-100 dark:from-yellow-900/30 dark:to-orange-900/30 hover:scale-105'
                      : 'bg-gray-100 dark:bg-gray-700 opacity-50 hover:opacity-70'
                  }`}
                  title={achievement.unlocked ? `Получено: ${achievement.date}` : 'Нажмите, чтобы разблокировать'}
                >
                  <div className="text-3xl mb-1">{achievement.icon}</div>
                  <div className="text-xs text-center text-gray-700 dark:text-gray-300">
                    {achievement.title}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Skills */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <h3 className="text-gray-900 dark:text-white mb-4">Навыки</h3>
            <div className="space-y-4">
              {skills.map((skill, idx) => (
                <div key={idx}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-700 dark:text-gray-300">{skill.name}</span>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">{skill.level}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all duration-500 ${skill.color}`}
                      style={{ width: `${skill.level}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg shadow-sm border border-blue-200 dark:border-blue-800 p-6">
            <h3 className="text-gray-900 dark:text-white mb-4">Статистика</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Посещаемость</span>
                <span className="text-lg font-medium text-gray-900 dark:text-white">95%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Средний балл</span>
                <span className="text-lg font-medium text-gray-900 dark:text-white">4.7</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Сданных работ</span>
                <span className="text-lg font-medium text-gray-900 dark:text-white">12/15</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-400">Активность</span>
                <span className="text-lg font-medium text-green-600 dark:text-green-400">Высокая</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Course2Page;