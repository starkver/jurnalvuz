import React, { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const CampusPage = () => {
  const [selectedFloor, setSelectedFloor] = useState(1);
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const floors = [
    {
      number: 1,
      rooms: [
        { id: 101, name: 'Аудитория 101', type: 'lecture', capacity: 50, position: { top: '20%', left: '10%' } },
        { id: 102, name: 'Аудитория 102', type: 'lecture', capacity: 40, position: { top: '20%', left: '40%' } },
        { id: 103, name: 'Лаборатория 103', type: 'lab', capacity: 25, position: { top: '50%', left: '10%' } },
        { id: 104, name: 'Кафетерий', type: 'cafeteria', capacity: 100, position: { top: '50%', left: '40%' } },
        { id: 105, name: 'Медпункт', type: 'medical', capacity: 10, position: { top: '80%', left: '10%' } },
      ]
    },
    {
      number: 2,
      rooms: [
        { id: 201, name: 'Аудитория 201', type: 'lecture', capacity: 60, position: { top: '20%', left: '10%' } },
        { id: 202, name: 'Компьютерный класс 202', type: 'computer', capacity: 30, position: { top: '20%', left: '40%' } },
        { id: 203, name: 'Лаборатория 203', type: 'lab', capacity: 20, position: { top: '50%', left: '10%' } },
        { id: 204, name: 'Библиотека', type: 'library', capacity: 50, position: { top: '50%', left: '40%' } },
      ]
    },
    {
      number: 3,
      rooms: [
        { id: 301, name: 'Аудитория 301', type: 'lecture', capacity: 45, position: { top: '20%', left: '10%' } },
        { id: 302, name: 'Аудитория 302', type: 'lecture', capacity: 45, position: { top: '20%', left: '40%' } },
        { id: 303, name: 'Кабинет декана', type: 'office', capacity: 5, position: { top: '50%', left: '10%' } },
        { id: 304, name: 'Конференц-зал', type: 'conference', capacity: 80, position: { top: '50%', left: '40%' } },
      ]
    },
    {
      number: 4,
      rooms: [
        { id: 401, name: 'Актовый зал', type: 'hall', capacity: 200, position: { top: '20%', left: '10%' } },
        { id: 402, name: 'Спортзал', type: 'gym', capacity: 50, position: { top: '50%', left: '10%' } },
        { id: 403, name: 'Административный офис', type: 'office', capacity: 15, position: { top: '80%', left: '10%' } },
      ]
    }
  ];

  const campusImages = [
    { id: 1, title: 'Главный вход', description: 'Центральный вход в учебный корпус' },
    { id: 2, title: 'Холл первого этажа', description: 'Просторный холл с информационными стендами' },
    { id: 3, title: 'Аудитория', description: 'Современная аудитория с мультимедийным оборудованием' },
    { id: 4, title: 'Библиотека', description: 'Читальный зал библиотеки' },
    { id: 5, title: 'Компьютерный класс', description: 'Класс с современными компьютерами' },
    { id: 6, title: 'Кафетерий', description: 'Уютный кафетерий для студентов' },
  ];

  const getRoomTypeIcon = (type: string) => {
    const icons = {
      lecture: '📚',
      lab: '🔬',
      computer: '💻',
      cafeteria: '🍽️',
      medical: '🏥',
      library: '📖',
      office: '🏢',
      conference: '🎤',
      hall: '🎭',
      gym: '🏋️'
    };
    return icons[type as keyof typeof icons] || '🏫';
  };

  const getRoomTypeColor = (type: string) => {
    const colors = {
      lecture: 'bg-blue-100 dark:bg-blue-900/30 border-blue-300 dark:border-blue-700',
      lab: 'bg-green-100 dark:bg-green-900/30 border-green-300 dark:border-green-700',
      computer: 'bg-purple-100 dark:bg-purple-900/30 border-purple-300 dark:border-purple-700',
      cafeteria: 'bg-orange-100 dark:bg-orange-900/30 border-orange-300 dark:border-orange-700',
      medical: 'bg-red-100 dark:bg-red-900/30 border-red-300 dark:border-red-700',
      library: 'bg-indigo-100 dark:bg-indigo-900/30 border-indigo-300 dark:border-indigo-700',
      office: 'bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600',
      conference: 'bg-pink-100 dark:bg-pink-900/30 border-pink-300 dark:border-pink-700',
      hall: 'bg-yellow-100 dark:bg-yellow-900/30 border-yellow-300 dark:border-yellow-700',
      gym: 'bg-teal-100 dark:bg-teal-900/30 border-teal-300 dark:border-teal-700'
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 border-gray-300';
  };

  const currentFloor = floors.find(f => f.number === selectedFloor);

  const openImageModal = (index: number) => {
    setSelectedImage(index);
    document.body.style.overflow = 'hidden';
  };

  const closeImageModal = () => {
    setSelectedImage(null);
    document.body.style.overflow = 'auto';
  };

  const navigateImage = (direction: 'prev' | 'next') => {
    if (selectedImage === null) return;
    
    if (direction === 'prev') {
      setSelectedImage(selectedImage === 0 ? campusImages.length - 1 : selectedImage - 1);
    } else {
      setSelectedImage(selectedImage === campusImages.length - 1 ? 0 : selectedImage + 1);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white p-8 rounded-lg">
        <h1 className="mb-2">Учебный корпус</h1>
        <p className="text-lg opacity-90">
          Информация о расположении, контактах и внутренней инфраструктуре
        </p>
      </div>

      {/* Contact Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center text-2xl">
              📍
            </div>
            <div>
              <h4 className="text-gray-900 dark:text-white mb-1">Адрес</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                г. Москва, ул. Университетская, д. 15
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center text-2xl">
              📞
            </div>
            <div>
              <h4 className="text-gray-900 dark:text-white mb-1">Телефон</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                +7 (495) 123-45-67
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center text-2xl">
              ✉️
            </div>
            <div>
              <h4 className="text-gray-900 dark:text-white mb-1">Email</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                corpus@university.edu
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/30 rounded-lg flex items-center justify-center text-2xl">
              🕐
            </div>
            <div>
              <h4 className="text-gray-900 dark:text-white mb-1">Режим работы</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Пн-Пт: 8:00-20:00<br />Сб: 9:00-15:00
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Map Section */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-gray-900 dark:text-white mb-4">Расположение</h3>
        <div className="aspect-video bg-gradient-to-br from-blue-50 to-green-50 dark:from-blue-900/20 dark:to-green-900/20 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 dark:border-gray-600 mb-4">
          <div className="text-center p-8">
            <div className="text-6xl mb-4">🗺️</div>
            <p className="text-gray-600 dark:text-gray-400">
              Интерактивная карта местоположения
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">
              Ближайшее метро: Университет (5 минут пешком)
            </p>
          </div>
        </div>
        <div className="text-sm text-gray-600 dark:text-gray-400">
          <p className="mb-2">
            <strong>Как добраться:</strong>
          </p>
          <ul className="list-disc list-inside space-y-1">
            <li>От м. Университет - 5 минут пешком</li>
            <li>Автобусы: 1, 113, 661 до остановки "Университет"</li>
            <li>Парковка для автомобилей на территории кампуса</li>
          </ul>
        </div>
      </div>

      {/* Floor Plans */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-gray-900 dark:text-white mb-4">Схема этажей</h3>
        
        {/* Floor Selector */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {floors.map((floor) => (
            <button
              key={floor.number}
              onClick={() => setSelectedFloor(floor.number)}
              className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 whitespace-nowrap ${
                selectedFloor === floor.number
                  ? 'bg-blue-600 text-white shadow-md scale-105'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              {floor.number} этаж
            </button>
          ))}
        </div>

        {/* Floor Plan */}
        <div className="relative bg-gradient-to-br from-gray-50 to-blue-50 dark:from-gray-900 dark:to-blue-900/20 rounded-lg p-8 min-h-[400px] border-2 border-gray-200 dark:border-gray-700">
          <div className="absolute top-4 right-4 bg-white dark:bg-gray-800 rounded-lg px-4 py-2 shadow-md">
            <div className="text-sm text-gray-600 dark:text-gray-400">
              Этаж {selectedFloor}
            </div>
          </div>

          {currentFloor?.rooms.map((room) => (
            <div
              key={room.id}
              className={`absolute w-32 h-24 rounded-lg border-2 p-3 cursor-pointer transition-all duration-200 hover:scale-110 hover:shadow-lg ${getRoomTypeColor(room.type)}`}
              style={{ top: room.position.top, left: room.position.left }}
              title={`${room.name} - Вместимость: ${room.capacity} чел.`}
            >
              <div className="text-2xl mb-1">{getRoomTypeIcon(room.type)}</div>
              <div className="text-xs font-medium text-gray-900 dark:text-white">
                {room.id}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400 truncate">
                {room.type === 'lecture' ? 'Аудитория' : 
                 room.type === 'lab' ? 'Лаборатория' :
                 room.type === 'computer' ? 'Комп. класс' :
                 room.type === 'office' ? 'Офис' :
                 room.name.split(' ')[0]}
              </div>
            </div>
          ))}
        </div>

        {/* Room Legend */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-5 gap-4">
          {[
            { type: 'lecture', label: 'Аудитория' },
            { type: 'lab', label: 'Лаборатория' },
            { type: 'computer', label: 'Комп. класс' },
            { type: 'office', label: 'Офис' },
            { type: 'cafeteria', label: 'Кафетерий' }
          ].map((item) => (
            <div key={item.type} className="flex items-center gap-2">
              <div className={`w-6 h-6 rounded border-2 ${getRoomTypeColor(item.type)}`}></div>
              <span className="text-sm text-gray-600 dark:text-gray-400">{item.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Photo Gallery */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-gray-900 dark:text-white mb-4">Фотогалерея корпуса</h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {campusImages.map((image, index) => (
            <div
              key={image.id}
              onClick={() => openImageModal(index)}
              className="group relative aspect-video bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 rounded-lg overflow-hidden cursor-pointer hover:shadow-xl transition-all duration-300 hover:scale-105"
            >
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center p-4">
                  <div className="text-4xl mb-2">🏫</div>
                  <div className="text-sm font-medium text-gray-900 dark:text-white">
                    {image.title}
                  </div>
                </div>
              </div>
              
              {/* Overlay on hover */}
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-300 flex items-center justify-center">
                <div className="text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Image Modal */}
      {selectedImage !== null && (
        <div
          className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4"
          onClick={closeImageModal}
        >
          <button
            onClick={closeImageModal}
            className="absolute top-4 right-4 text-white hover:text-gray-300 transition-colors"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              navigateImage('prev');
            }}
            className="absolute left-4 text-white hover:text-gray-300 transition-colors"
          >
            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              navigateImage('next');
            }}
            className="absolute right-4 text-white hover:text-gray-300 transition-colors"
          >
            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>

          <div
            className="max-w-4xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 rounded-lg aspect-video flex items-center justify-center mb-4">
              <div className="text-center p-8">
                <div className="text-6xl mb-4">🏫</div>
                <h3 className="text-gray-900 dark:text-white mb-2">
                  {campusImages[selectedImage].title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {campusImages[selectedImage].description}
                </p>
              </div>
            </div>
            <div className="text-center text-white text-sm">
              {selectedImage + 1} / {campusImages.length}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CampusPage;