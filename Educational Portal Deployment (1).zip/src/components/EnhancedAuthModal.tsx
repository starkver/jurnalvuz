import React, { useState } from 'react';

interface EnhancedAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (userData: any) => void;
}

interface FormData {
  // Basic fields
  fullName: string;
  password: string;
  confirmPassword: string;
  
  // Registration fields
  lastName: string;
  firstName: string;
  middleName: string;
  userType: 'student' | 'teacher' | 'admin';
  institution: string;
  groupNumber: string;
  department: string;
  inviteCode: string;
  
  // Agreement
  agreeToTerms: boolean;
}

const EnhancedAuthModal: React.FC<EnhancedAuthModalProps> = ({ isOpen, onClose, onLogin }) => {
  const [currentStep, setCurrentStep] = useState<'login' | 'register' | 'forgot-password' | 'verify-code' | 'new-password'>('login');
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    password: '',
    confirmPassword: '',
    lastName: '',
    firstName: '',
    middleName: '',
    userType: 'student',
    institution: '',
    groupNumber: '',
    department: '',
    inviteCode: '',
    agreeToTerms: false
  });
  const [errors, setErrors] = useState<any>({});
  const [isLoading, setIsLoading] = useState(false);
  const [resetCode, setResetCode] = useState('');
  const [countdown, setCountdown] = useState(0);
  const [showPassword, setShowPassword] = useState(false);

  if (!isOpen) return null;

  const institutions = [
    'МГУ им. М.В. Ломоносова',
    'СПбГУ',
    'МФТИ',
    'МГТУ им. Н.Э. Баумана',
    'ВШЭ',
    'ИТМО',
    'Другое'
  ];

  const userTypes = [
    {
      id: 'student',
      title: 'Студент',
      description: 'Для обучающихся',
      icon: '👨‍🎓'
    },
    {
      id: 'teacher',
      title: 'Преподаватель',
      description: 'Для преподавательского состава',
      icon: '👨‍🏫'
    },
    {
      id: 'admin',
      title: 'Администратор',
      description: 'Для управленческого персонала',
      icon: '⚙️'
    }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const inputValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    
    setFormData(prev => ({ ...prev, [name]: inputValue }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateFullName = (fullName: string) => {
    // ФИО должно содержать минимум 2 слова (Фамилия Имя)
    const parts = fullName.trim().split(/\s+/);
    return parts.length >= 2 && parts.every(part => part.length > 0);
  };

  const validatePassword = (password: string) => {
    const hasMinLength = password.length >= 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    return {
      isValid: hasMinLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecial,
      requirements: {
        minLength: hasMinLength,
        upperCase: hasUpperCase,
        lowerCase: hasLowerCase,
        numbers: hasNumbers,
        special: hasSpecial
      }
    };
  };

  const validateForm = () => {
    const newErrors: any = {};

    if (currentStep === 'login') {
      if (!formData.fullName.trim()) {
        newErrors.fullName = 'ФИО обязательно';
      } else if (!validateFullName(formData.fullName)) {
        newErrors.fullName = 'Введите полное ФИО (минимум Фамилия и Имя)';
      }
    }

    if (!formData.password) {
      newErrors.password = 'Пароль обязателен';
    } else if (currentStep === 'register') {
      const passwordValidation = validatePassword(formData.password);
      if (!passwordValidation.isValid) {
        newErrors.password = 'Пароль не соответствует требованиям';
      }
    }

    if (currentStep === 'register') {
      if (!formData.lastName.trim()) {
        newErrors.lastName = 'Фамилия обязательна';
      }
      if (!formData.firstName.trim()) {
        newErrors.firstName = 'Имя обязательно';
      }
      if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = 'Пароли не совпадают';
      }
      if (!formData.institution) {
        newErrors.institution = 'Выберите учебное заведение';
      }
      if ((formData.userType === 'student' || formData.userType === 'teacher') && !formData.groupNumber.trim()) {
        newErrors.groupNumber = formData.userType === 'student' ? 'Номер группы обязателен' : 'Кафедра обязательна';
      }
      if (formData.userType === 'admin' && !formData.inviteCode.trim()) {
        newErrors.inviteCode = 'Код приглашения обязателен для администраторов';
      }
      if (!formData.agreeToTerms) {
        newErrors.agreeToTerms = 'Необходимо согласиться с условиями';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);

    setTimeout(() => {
      let fullName, firstName, lastName, middleName;
      
      if (currentStep === 'login') {
        // При входе используем ФИО из поля fullName
        fullName = formData.fullName.trim();
        const nameParts = fullName.split(/\s+/);
        lastName = nameParts[0] || '';
        firstName = nameParts[1] || '';
        middleName = nameParts[2] || '';
      } else {
        // При регистрации используем отдельные поля
        lastName = formData.lastName.trim();
        firstName = formData.firstName.trim();
        middleName = formData.middleName.trim();
        fullName = `${lastName} ${firstName} ${middleName}`.trim();
      }
      
      const userData = {
        id: Date.now(),
        firstName: firstName,
        lastName: lastName,
        middleName: middleName,
        name: fullName,
        email: `${lastName.toLowerCase()}.${firstName.toLowerCase()}@edu.local`, // Генерируем email для совместимости
        userType: currentStep === 'register' ? formData.userType : 'student',
        institution: formData.institution || 'МГУ им. М.В. Ломоносова',
        groupNumber: formData.groupNumber || '1',
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${fullName}`,
        course: formData.userType === 'student' ? '1' : undefined
      };
      
      localStorage.setItem('user', JSON.stringify(userData));
      onLogin(userData);
      setIsLoading(false);
      onClose();
      resetForm();
    }, 1000);
  };

  const resetForm = () => {
    setFormData({
      fullName: '',
      password: '',
      confirmPassword: '',
      lastName: '',
      firstName: '',
      middleName: '',
      userType: 'student',
      institution: '',
      groupNumber: '',
      department: '',
      inviteCode: '',
      agreeToTerms: false
    });
    setErrors({});
    setCurrentStep('login');
  };

  const startCountdown = () => {
    setCountdown(60);
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const renderPasswordRequirements = () => {
    if (currentStep !== 'register' || !formData.password) return null;
    
    const validation = validatePassword(formData.password);
    
    return (
      <div className="mt-2 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
        <p className="text-xs text-gray-600 dark:text-gray-300 mb-2">Требования к паролю:</p>
        <div className="grid grid-cols-2 gap-1 text-xs">
          <div className={validation.requirements.minLength ? 'text-green-600 dark:text-green-400' : 'text-red-500'}>
            ✓ Минимум 8 символов
          </div>
          <div className={validation.requirements.upperCase ? 'text-green-600 dark:text-green-400' : 'text-red-500'}>
            ✓ Заглавные буквы
          </div>
          <div className={validation.requirements.lowerCase ? 'text-green-600 dark:text-green-400' : 'text-red-500'}>
            ✓ Строчные буквы
          </div>
          <div className={validation.requirements.numbers ? 'text-green-600 dark:text-green-400' : 'text-red-500'}>
            ✓ Цифры
          </div>
          <div className={validation.requirements.special ? 'text-green-600 dark:text-green-400' : 'text-red-500'}>
            ✓ Спецсимволы
          </div>
        </div>
      </div>
    );
  };

  const renderLoginForm = () => (
    <>
      <div className="text-center mb-6">
        <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
          Войдите в свой аккаунт
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Доступ к личному кабинету
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            ФИО (Фамилия Имя Отчество)
          </label>
          <input
            type="text"
            name="fullName"
            value={formData.fullName}
            onChange={handleInputChange}
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white ${
              errors.fullName ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
            }`}
            placeholder="Иванов Иван Иванович"
          />
          {errors.fullName && <p className="text-red-500 text-sm mt-1">{errors.fullName}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Пароль
          </label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              className={`w-full px-4 py-3 pr-12 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white ${
                errors.password ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
              }`}
              placeholder="Введите пароль"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              {showPassword ? '👁️' : '👁️‍🗨️'}
            </button>
          </div>
          {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password}</p>}
        </div>

        <div className="flex items-center justify-between">
          <label className="flex items-center">
            <input type="checkbox" className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50" />
            <span className="ml-2 text-sm text-gray-600 dark:text-gray-300">Запомнить меня</span>
          </label>
          <button
            type="button"
            onClick={() => setCurrentStep('forgot-password')}
            className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
          >
            Забыли пароль?
          </button>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white py-3 px-4 rounded-lg transition-colors flex items-center justify-center"
        >
          {isLoading ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          ) : (
            'Войти'
          )}
        </button>
      </form>

      <div className="mt-6 text-center">
        <p className="text-sm text-gray-600 dark:text-gray-400">
          Нет аккаунта?
          <button
            onClick={() => setCurrentStep('register')}
            className="ml-1 font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
          >
            Зарегистрироваться
          </button>
        </p>
      </div>

      <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
        <p className="text-xs text-blue-600 dark:text-blue-400">
          💡 Для демонстрации: введите ваше ФИО и любой пароль
        </p>
      </div>
    </>
  );

  const renderRegistrationForm = () => (
    <>
      <div className="text-center mb-6">
        <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
          Создайте свой аккаунт
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Заполните форму для регистрации в образовательном портале
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* User Type Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
            Тип аккаунта
          </label>
          <div className="grid grid-cols-1 gap-3">
            {userTypes.map((type) => (
              <label
                key={type.id}
                className={`relative flex items-center p-4 border rounded-lg cursor-pointer transition-colors ${
                  formData.userType === type.id
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
              >
                <input
                  type="radio"
                  name="userType"
                  value={type.id}
                  checked={formData.userType === type.id}
                  onChange={handleInputChange}
                  className="sr-only"
                />
                <div className="text-2xl mr-3">{type.icon}</div>
                <div>
                  <div className="font-medium text-gray-900 dark:text-white">{type.title}</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">{type.description}</div>
                </div>
                {formData.userType === type.id && (
                  <div className="absolute right-4 text-blue-500">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"/>
                    </svg>
                  </div>
                )}
              </label>
            ))}
          </div>
        </div>

        {/* Name Fields */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Фамилия *
          </label>
          <input
            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleInputChange}
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white ${
              errors.lastName ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
            }`}
            placeholder="Иванов"
          />
          {errors.lastName && <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Имя *
            </label>
            <input
              type="text"
              name="firstName"
              value={formData.firstName}
              onChange={handleInputChange}
              className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white ${
                errors.firstName ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
              }`}
              placeholder="Иван"
            />
            {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Отчество
            </label>
            <input
              type="text"
              name="middleName"
              value={formData.middleName}
              onChange={handleInputChange}
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              placeholder="Иванович"
            />
          </div>
        </div>

        {/* Password */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Пароль *
          </label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              className={`w-full px-4 py-3 pr-12 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white ${
                errors.password ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
              }`}
              placeholder="Введите надежный пароль"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              {showPassword ? '👁️' : '👁️‍🗨️'}
            </button>
          </div>
          {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password}</p>}
          {renderPasswordRequirements()}
        </div>

        {/* Confirm Password */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Подтвердите пароль *
          </label>
          <input
            type="password"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleInputChange}
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white ${
              errors.confirmPassword ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
            }`}
            placeholder="Повторите пароль"
          />
          {errors.confirmPassword && <p className="text-red-500 text-sm mt-1">{errors.confirmPassword}</p>}
        </div>

        {/* Institution */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Учебное заведение *
          </label>
          <select
            name="institution"
            value={formData.institution}
            onChange={handleInputChange}
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white ${
              errors.institution ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
            }`}
          >
            <option value="">Выберите учебное заведение</option>
            {institutions.map((inst) => (
              <option key={inst} value={inst}>{inst}</option>
            ))}
          </select>
          {errors.institution && <p className="text-red-500 text-sm mt-1">{errors.institution}</p>}
        </div>

        {/* Group/Department */}
        {(formData.userType === 'student' || formData.userType === 'teacher') && (
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              {formData.userType === 'student' ? 'Номер группы *' : 'Кафедра *'}
            </label>
            <input
              type="text"
              name="groupNumber"
              value={formData.groupNumber}
              onChange={handleInputChange}
              className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white ${
                errors.groupNumber ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
              }`}
              placeholder={formData.userType === 'student' ? 'Например: ИТ-101' : 'Например: Кафедра ИТ'}
            />
            {errors.groupNumber && <p className="text-red-500 text-sm mt-1">{errors.groupNumber}</p>}
          </div>
        )}

        {/* Admin Invite Code */}
        {formData.userType === 'admin' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Код приглашения *
            </label>
            <input
              type="text"
              name="inviteCode"
              value={formData.inviteCode}
              onChange={handleInputChange}
              className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white ${
                errors.inviteCode ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
              }`}
              placeholder="Введите код приглашения"
            />
            {errors.inviteCode && <p className="text-red-500 text-sm mt-1">{errors.inviteCode}</p>}
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              Код приглашения предоставляется системным администратором
            </p>
          </div>
        )}

        {/* Terms Agreement */}
        <div>
          <label className="flex items-start">
            <input
              type="checkbox"
              name="agreeToTerms"
              checked={formData.agreeToTerms}
              onChange={handleInputChange}
              className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50 mt-1"
            />
            <span className="ml-2 text-sm text-gray-600 dark:text-gray-300">
              Я согласен с{' '}
              <a href="#" className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300">
                условиями использования
              </a>{' '}
              и{' '}
              <a href="#" className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300">
                политикой конфиденциальности
              </a>
            </span>
          </label>
          {errors.agreeToTerms && <p className="text-red-500 text-sm mt-1">{errors.agreeToTerms}</p>}
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white py-3 px-4 rounded-lg transition-colors flex items-center justify-center"
        >
          {isLoading ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          ) : (
            'Зарегистрироваться'
          )}
        </button>
      </form>

      <div className="mt-6 text-center">
        <p className="text-sm text-gray-600 dark:text-gray-400">
          Уже есть аккаунт?
          <button
            onClick={() => setCurrentStep('login')}
            className="ml-1 font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
          >
            Войти
          </button>
        </p>
      </div>
    </>
  );

  const renderForgotPassword = () => (
    <>
      <div className="text-center mb-6">
        <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
          Восстановление пароля
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Введите ваше ФИО для получения кода восстановления
        </p>
      </div>

      <form onSubmit={(e) => {
        e.preventDefault();
        if (formData.fullName) {
          setCurrentStep('verify-code');
          startCountdown();
        }
      }} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            ФИО (Фамилия Имя Отчество)
          </label>
          <input
            type="text"
            name="fullName"
            value={formData.fullName}
            onChange={handleInputChange}
            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
            placeholder="Иванов Иван Иванович"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg transition-colors"
        >
          Отправить код
        </button>
      </form>

      <div className="mt-6 text-center">
        <button
          onClick={() => setCurrentStep('login')}
          className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
        >
          ← Вернуться к входу
        </button>
      </div>
    </>
  );

  const renderVerifyCode = () => (
    <>
      <div className="text-center mb-6">
        <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
          Подтверждение личности
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Код восстановления отправлен для {formData.fullName}
        </p>
      </div>

      <form onSubmit={(e) => {
        e.preventDefault();
        if (resetCode.length === 6) {
          setCurrentStep('new-password');
        }
      }} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Код подтверждения
          </label>
          <input
            type="text"
            value={resetCode}
            onChange={(e) => setResetCode(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white text-center text-2xl tracking-widest"
            placeholder="000000"
            maxLength={6}
          />
        </div>

        <button
          type="submit"
          disabled={resetCode.length !== 6}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white py-3 px-4 rounded-lg transition-colors"
        >
          Подтвердить код
        </button>

        <div className="text-center">
          {countdown > 0 ? (
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Повторная отправка через {countdown} сек
            </p>
          ) : (
            <button
              type="button"
              onClick={() => startCountdown()}
              className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
            >
              Отправить код повторно
            </button>
          )}
        </div>
      </form>
    </>
  );

  const renderNewPassword = () => (
    <>
      <div className="text-center mb-6">
        <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
          Новый пароль
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Создайте новый надежный пароль
        </p>
      </div>

      <form onSubmit={(e) => {
        e.preventDefault();
        if (formData.password && formData.password === formData.confirmPassword) {
          // Simulate password reset success
          setCurrentStep('login');
          alert('Пароль успешно изменен!');
        }
      }} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Новый пароль
          </label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
            placeholder="Введите новый пароль"
          />
          {renderPasswordRequirements()}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Подтвердите новый пароль
          </label>
          <input
            type="password"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleInputChange}
            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
            placeholder="Повторите новый пароль"
          />
        </div>

        <button
          type="submit"
          disabled={!formData.password || formData.password !== formData.confirmPassword}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white py-3 px-4 rounded-lg transition-colors"
        >
          Сохранить пароль
        </button>
      </form>
    </>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-800 dark:to-gray-900 rounded-lg shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="w-8"></div>
            <button
              onClick={() => {
                onClose();
                resetForm();
              }}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 p-1"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-inner">
            {currentStep === 'login' && renderLoginForm()}
            {currentStep === 'register' && renderRegistrationForm()}
            {currentStep === 'forgot-password' && renderForgotPassword()}
            {currentStep === 'verify-code' && renderVerifyCode()}
            {currentStep === 'new-password' && renderNewPassword()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnhancedAuthModal;