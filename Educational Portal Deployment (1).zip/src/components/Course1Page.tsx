import React, { useState } from 'react';

const Course1Page = () => {
  const [activeTab, setActiveTab] = useState('lectures');
  const [checkedMaterials, setCheckedMaterials] = useState<string[]>([]);

  const tabs = [
    { id: 'lectures', label: 'Лекции', icon: '📚' },
    { id: 'labs', label: 'Лабораторные', icon: '🔬' },
    { id: 'tests', label: 'Тесты', icon: '📝' },
    { id: 'materials', label: 'Материалы', icon: '📁' }
  ];

  const lectures = [
    {
      id: 1,
      title: 'Введение в программирование',
      date: '15.01.2024',
      duration: '1.5 часа',
      status: 'completed'
    },
    {
      id: 2,
      title: 'Основы алгоритмизации',
      date: '22.01.2024',
      duration: '2 часа',
      status: 'completed'
    },
    {
      id: 3,
      title: 'Структуры данных',
      date: '29.01.2024',
      duration: '1.5 часа',
      status: 'available'
    },
    {
      id: 4,
      title: 'Объектно-ориентированное программирование',
      date: '05.02.2024',
      duration: '2 часа',
      status: 'locked'
    }
  ];

  const labs = [
    {
      id: 1,
      title: 'Лабораторная работа №1: Hello World',
      deadline: '25.01.2024',
      status: 'submitted',
      grade: 95
    },
    {
      id: 2,
      title: 'Лабораторная работа №2: Калькулятор',
      deadline: '01.02.2024',
      status: 'in-progress',
      grade: null
    },
    {
      id: 3,
      title: 'Лабораторная работа №3: Работа с массивами',
      deadline: '08.02.2024',
      status: 'not-started',
      grade: null
    }
  ];

  const tests = [
    {
      id: 1,
      title: 'Тест №1: Основы программирования',
      questions: 20,
      time: '30 минут',
      attempts: 2,
      status: 'completed',
      score: 85
    },
    {
      id: 2,
      title: 'Тест №2: Алгоритмы',
      questions: 15,
      time: '25 минут',
      attempts: 3,
      status: 'available',
      score: null
    }
  ];

  const materials = [
    { id: 'm1', title: 'Конспект лекций', type: 'PDF', size: '2.5 MB' },
    { id: 'm2', title: 'Примеры кода', type: 'ZIP', size: '1.2 MB' },
    { id: 'm3', title: 'Дополнительная литература', type: 'PDF', size: '5.8 MB' },
    { id: 'm4', title: 'Видеоуроки', type: 'Link', size: '-' }
  ];

  const toggleMaterial = (id: string) => {
    setCheckedMaterials(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const getStatusBadge = (status: string) => {
    const badges = {
      completed: { text: 'Завершено', class: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' },
      available: { text: 'Доступно', class: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400' },
      locked: { text: 'Заблокировано', class: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-400' },
      submitted: { text: 'Отправлено', class: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400' },
      'in-progress': { text: 'В процессе', class: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400' },
      'not-started': { text: 'Не начато', class: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-400' }
    };
    const badge = badges[status as keyof typeof badges] || badges.available;
    return <span className={`px-2 py-1 rounded-full text-xs ${badge.class}`}>{badge.text}</span>;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-blue-600 text-white p-6 rounded-lg">
        <h1 className="mb-2">1 курс</h1>
        <p className="text-lg opacity-90">Основы программирования и алгоритмизации</p>
        <div className="mt-4 flex flex-wrap gap-4">
          <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
            <div className="text-sm opacity-80">Прогресс курса</div>
            <div className="text-2xl">65%</div>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
            <div className="text-sm opacity-80">Активных заданий</div>
            <div className="text-2xl">3</div>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
            <div className="text-sm opacity-80">Средний балл</div>
            <div className="text-2xl">4.5</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex flex-wrap -mb-px">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-4 border-b-2 transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300'
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {/* Lectures Tab */}
          {activeTab === 'lectures' && (
            <div className="space-y-4">
              <h3 className="text-gray-900 dark:text-white mb-4">Лекционный материал</h3>
              {lectures.map((lecture) => (
                <div
                  key={lecture.id}
                  className={`border rounded-lg p-4 transition-all duration-200 ${
                    lecture.status === 'locked'
                      ? 'bg-gray-50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600 opacity-60'
                      : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:shadow-md hover:border-blue-300 dark:hover:border-blue-600 cursor-pointer'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <div className="text-2xl">
                          {lecture.status === 'completed' ? '✅' : lecture.status === 'locked' ? '🔒' : '📖'}
                        </div>
                        <div>
                          <h4 className="text-gray-900 dark:text-white">{lecture.title}</h4>
                          <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {lecture.date} · {lecture.duration}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div>
                      {getStatusBadge(lecture.status)}
                    </div>
                  </div>
                  {lecture.status !== 'locked' && (
                    <div className="mt-4 flex gap-2">
                      <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all duration-200 hover:scale-95">
                        {lecture.status === 'completed' ? 'Повторить' : 'Начать изучение'}
                      </button>
                      {lecture.status === 'completed' && (
                        <button className="border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-all duration-200">
                          Скачать конспект
                        </button>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Labs Tab */}
          {activeTab === 'labs' && (
            <div className="space-y-4">
              <h3 className="text-gray-900 dark:text-white mb-4">Лабораторные работы</h3>
              {labs.map((lab) => (
                <div
                  key={lab.id}
                  className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 bg-white dark:bg-gray-800 hover:shadow-md transition-all duration-200"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="text-gray-900 dark:text-white">{lab.title}</h4>
                      <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        Срок сдачи: {lab.deadline}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      {getStatusBadge(lab.status)}
                      {lab.grade !== null && (
                        <div className="text-2xl font-medium text-green-600 dark:text-green-400">
                          {lab.grade}%
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    {lab.status === 'not-started' && (
                      <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all duration-200 hover:scale-95">
                        Начать работу
                      </button>
                    )}
                    {lab.status === 'in-progress' && (
                      <>
                        <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-all duration-200 hover:scale-95">
                          Сдать работу
                        </button>
                        <button className="border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-all duration-200">
                          Продолжить
                        </button>
                      </>
                    )}
                    {lab.status === 'submitted' && (
                      <button className="border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-all duration-200">
                        Просмотреть результат
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Tests Tab */}
          {activeTab === 'tests' && (
            <div className="space-y-4">
              <h3 className="text-gray-900 dark:text-white mb-4">Контрольные тесты</h3>
              {tests.map((test) => (
                <div
                  key={test.id}
                  className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 bg-white dark:bg-gray-800 hover:shadow-md transition-all duration-200"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="text-gray-900 dark:text-white">{test.title}</h4>
                      <div className="text-sm text-gray-600 dark:text-gray-400 mt-2 space-y-1">
                        <div>📊 Вопросов: {test.questions}</div>
                        <div>⏱️ Время: {test.time}</div>
                        <div>🔄 Попыток осталось: {test.attempts}</div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      {getStatusBadge(test.status)}
                      {test.score !== null && (
                        <div className="text-2xl font-medium text-blue-600 dark:text-blue-400">
                          {test.score}%
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="mt-4">
                    {test.status === 'available' && (
                      <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all duration-200 hover:scale-95">
                        Начать тест
                      </button>
                    )}
                    {test.status === 'completed' && (
                      <div className="flex gap-2">
                        <button className="border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-all duration-200">
                          Просмотреть результаты
                        </button>
                        {test.attempts > 0 && (
                          <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all duration-200 hover:scale-95">
                            Пройти повторно
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Materials Tab */}
          {activeTab === 'materials' && (
            <div className="space-y-4">
              <h3 className="text-gray-900 dark:text-white mb-4">Учебные материалы</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {materials.map((material) => (
                  <div
                    key={material.id}
                    onClick={() => toggleMaterial(material.id)}
                    className={`border rounded-lg p-4 cursor-pointer transition-all duration-200 ${
                      checkedMaterials.includes(material.id)
                        ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-600'
                        : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:border-blue-200 dark:hover:border-blue-700'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="text-2xl">
                          {material.type === 'PDF' ? '📄' : material.type === 'ZIP' ? '📦' : '🔗'}
                        </div>
                        <div className="flex-1">
                          <h4 className="text-gray-900 dark:text-white">{material.title}</h4>
                          <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {material.type} · {material.size}
                          </div>
                        </div>
                      </div>
                      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                        checkedMaterials.includes(material.id)
                          ? 'bg-blue-600 border-blue-600'
                          : 'border-gray-300 dark:border-gray-600'
                      }`}>
                        {checkedMaterials.includes(material.id) && (
                          <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                        }}
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg text-sm transition-all duration-200 hover:scale-95"
                      >
                        Скачать
                      </button>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                        }}
                        className="border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 px-3 py-2 rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-all duration-200"
                      >
                        Просмотр
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Course1Page;