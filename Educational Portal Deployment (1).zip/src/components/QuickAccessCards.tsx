import React from 'react';

interface QuickAccessCardsProps {
  onNavigate: (section: string) => void;
}

const QuickAccessCards: React.FC<QuickAccessCardsProps> = ({ onNavigate }) => {
  const quickLinks = [
    {
      id: 'course1',
      title: '1 курс',
      description: 'Основы программирования',
      icon: '📚',
      gradient: 'from-indigo-500 to-blue-600',
      action: () => onNavigate('course1')
    },
    {
      id: 'course2',
      title: '2 курс',
      description: 'Продвинутая разработка',
      icon: '🚀',
      gradient: 'from-purple-500 to-pink-600',
      action: () => onNavigate('course2')
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {quickLinks.map((link) => (
        <button
          key={link.id}
          onClick={link.action}
          className={`bg-gradient-to-br ${link.gradient} text-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105 text-left group`}
        >
          <div className="flex items-center gap-4">
            <div className="text-4xl group-hover:scale-110 transition-transform">
              {link.icon}
            </div>
            <div className="flex-1">
              <h4 className="mb-1">{link.title}</h4>
              <p className="text-sm text-white/80">{link.description}</p>
            </div>
            <svg 
              className="w-6 h-6 group-hover:translate-x-2 transition-transform" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </button>
      ))}
    </div>
  );
};

export default QuickAccessCards;