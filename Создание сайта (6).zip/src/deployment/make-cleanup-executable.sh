#!/bin/bash

# Делаем скрипт очистки исполняемым

chmod +x deployment/cleanup-and-reinstall.sh

echo "✅ Скрипт cleanup-and-reinstall.sh сделан исполняемым"
echo "🚀 Теперь можно запустить: bash deployment/cleanup-and-reinstall.sh"