#!/bin/bash

# Скрипт обновления образовательного портала
# Запуск: bash update.sh

set -e

PROJECT_PATH="/var/www/educational-portal"
BACKUP_PATH="/var/backups/educational-portal"

# Цвета для вывода
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
    exit 1
}

# Проверка прав root
if [ "$EUID" -ne 0 ]; then
    error "Запустите скрипт с правами root (sudo bash update.sh)"
fi

# Переход в директорию проекта
cd $PROJECT_PATH || error "Директория проекта не найдена: $PROJECT_PATH"

log "🔄 Начинаем обновление сайта..."

# Создание резервной копии
log "Создание резервной копии..."
tar -czf "$BACKUP_PATH/backup-before-update-$(date +%Y%m%d-%H%M%S).tar.gz" dist/

# Сборка проекта
log "Пересборка проекта..."
npm run build

# Настройка прав
log "Настройка прав доступа..."
chown -R www-data:www-data dist/
chmod -R 755 dist/

# Очистка кэша nginx (опционально)
log "Очистка кэша nginx..."
systemctl reload nginx

log "✅ Обновление завершено успешно!"
log "🌐 Изменения доступны на сайте"