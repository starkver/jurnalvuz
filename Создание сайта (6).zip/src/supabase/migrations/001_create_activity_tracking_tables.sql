-- Migration: Enhanced User Activity Tracking System
-- This migration creates tables for comprehensive user activity tracking

-- 1. Update users_profiles table with additional tracking fields
ALTER TABLE IF EXISTS users_profiles 
ADD COLUMN IF NOT EXISTS total_login_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_session_time_minutes INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_activity TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS favorite_sections TEXT[],
ADD COLUMN IF NOT EXISTS achievements_earned TEXT[],
ADD COLUMN IF NOT EXISTS files_accessed TEXT[],
ADD COLUMN IF NOT EXISTS journal_entries_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS profile_completion_percentage INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS preferences JSONB DEFAULT '{}',
ADD COLUMN IF NOT EXISTS learning_progress JSONB DEFAULT '{}';

-- 2. Create user_activities table for detailed activity logging
CREATE TABLE IF NOT EXISTS user_activities (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id TEXT NOT NULL,
    activity_type TEXT NOT NULL CHECK (activity_type IN (
        'login', 'logout', 'page_visit', 'file_view', 'journal_access', 
        'profile_edit', 'achievement_earned', 'course_material_access'
    )),
    details JSONB DEFAULT '{}',
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    session_id TEXT,
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_user_activities_user_id ON user_activities(user_id);
CREATE INDEX IF NOT EXISTS idx_user_activities_timestamp ON user_activities(timestamp);
CREATE INDEX IF NOT EXISTS idx_user_activities_type ON user_activities(activity_type);
CREATE INDEX IF NOT EXISTS idx_user_activities_session ON user_activities(session_id);

-- 3. Create user_sessions table for session tracking
CREATE TABLE IF NOT EXISTS user_sessions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id TEXT NOT NULL,
    session_start TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    session_end TIMESTAMP WITH TIME ZONE,
    duration_minutes INTEGER,
    pages_visited INTEGER DEFAULT 0,
    activities_count INTEGER DEFAULT 0,
    last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for sessions
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_start ON user_sessions(session_start);

-- 4. Create user_file_access table for file access tracking
CREATE TABLE IF NOT EXISTS user_file_access (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_type TEXT,
    file_path TEXT,
    access_timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    session_id TEXT,
    view_duration_seconds INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_file_access_user_id ON user_file_access(user_id);
CREATE INDEX IF NOT EXISTS idx_user_file_access_timestamp ON user_file_access(access_timestamp);

-- 5. Create learning_analytics table for advanced analytics
CREATE TABLE IF NOT EXISTS learning_analytics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id TEXT NOT NULL,
    date DATE DEFAULT CURRENT_DATE,
    total_activities INTEGER DEFAULT 0,
    unique_pages_visited INTEGER DEFAULT 0,
    files_accessed INTEGER DEFAULT 0,
    session_time_minutes INTEGER DEFAULT 0,
    achievements_earned INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, date)
);

CREATE INDEX IF NOT EXISTS idx_learning_analytics_user_date ON learning_analytics(user_id, date);

-- 6. Function to update user session statistics
CREATE OR REPLACE FUNCTION update_user_session_stats(
    user_id TEXT,
    additional_minutes INTEGER DEFAULT 0,
    additional_login INTEGER DEFAULT 0
)
RETURNS VOID AS $$
BEGIN
    UPDATE users_profiles 
    SET 
        total_session_time_minutes = COALESCE(total_session_time_minutes, 0) + additional_minutes,
        total_login_count = COALESCE(total_login_count, 0) + additional_login,
        last_activity = NOW()
    WHERE id = user_id;
END;
$$ LANGUAGE plpgsql;

-- 7. Function to calculate profile completion percentage
CREATE OR REPLACE FUNCTION calculate_profile_completion(user_id TEXT)
RETURNS INTEGER AS $$
DECLARE
    completion_percentage INTEGER := 0;
    profile_record RECORD;
BEGIN
    SELECT * INTO profile_record FROM users_profiles WHERE id = user_id;
    
    IF profile_record IS NULL THEN
        RETURN 0;
    END IF;
    
    -- Base required fields (40%)
    IF profile_record.username IS NOT NULL AND profile_record.username != '' THEN
        completion_percentage := completion_percentage + 20;
    END IF;
    
    IF profile_record.role IS NOT NULL THEN
        completion_percentage := completion_percentage + 20;
    END IF;
    
    -- Additional fields (60%)
    IF profile_record.first_name IS NOT NULL AND profile_record.first_name != '' THEN
        completion_percentage := completion_percentage + 15;
    END IF;
    
    IF profile_record.last_name IS NOT NULL AND profile_record.last_name != '' THEN
        completion_percentage := completion_percentage + 15;
    END IF;
    
    IF profile_record.phone IS NOT NULL AND profile_record.phone != '' THEN
        completion_percentage := completion_percentage + 10;
    END IF;
    
    IF profile_record.avatar_url IS NOT NULL AND profile_record.avatar_url != '' THEN
        completion_percentage := completion_percentage + 10;
    END IF;
    
    IF profile_record.course IS NOT NULL AND profile_record.course != '' THEN
        completion_percentage := completion_percentage + 10;
    END IF;
    
    -- Update the profile with calculated percentage
    UPDATE users_profiles 
    SET profile_completion_percentage = completion_percentage 
    WHERE id = user_id;
    
    RETURN completion_percentage;
END;
$$ LANGUAGE plpgsql;

-- 8. Trigger to update learning analytics daily
CREATE OR REPLACE FUNCTION update_daily_analytics()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO learning_analytics (user_id, date, total_activities)
    VALUES (NEW.user_id, CURRENT_DATE, 1)
    ON CONFLICT (user_id, date)
    DO UPDATE SET 
        total_activities = learning_analytics.total_activities + 1,
        updated_at = NOW();
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for activity tracking
DROP TRIGGER IF EXISTS trigger_update_daily_analytics ON user_activities;
CREATE TRIGGER trigger_update_daily_analytics
    AFTER INSERT ON user_activities
    FOR EACH ROW
    EXECUTE FUNCTION update_daily_analytics();

-- 9. Function to get user activity summary
CREATE OR REPLACE FUNCTION get_user_activity_summary(
    input_user_id TEXT,
    days_back INTEGER DEFAULT 7
)
RETURNS TABLE (
    total_activities BIGINT,
    unique_days_active BIGINT,
    most_common_activity TEXT,
    avg_daily_activities NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    WITH activity_stats AS (
        SELECT 
            COUNT(*) as total_count,
            COUNT(DISTINCT DATE(timestamp)) as unique_days,
            activity_type,
            COUNT(*) OVER (PARTITION BY activity_type) as type_count
        FROM user_activities 
        WHERE user_id = input_user_id 
            AND timestamp >= NOW() - INTERVAL '%s days' % days_back
        GROUP BY activity_type
    ),
    most_common AS (
        SELECT activity_type 
        FROM activity_stats 
        ORDER BY type_count DESC 
        LIMIT 1
    )
    SELECT 
        (SELECT SUM(total_count) FROM activity_stats)::BIGINT,
        (SELECT MAX(unique_days) FROM activity_stats)::BIGINT,
        (SELECT activity_type FROM most_common),
        ROUND((SELECT SUM(total_count) FROM activity_stats)::NUMERIC / days_back, 2)
    ;
END;
$$ LANGUAGE plpgsql;

-- 10. Create RLS (Row Level Security) policies
ALTER TABLE user_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_file_access ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_analytics ENABLE ROW LEVEL SECURITY;

-- Policies for user_activities
CREATE POLICY "Users can view their own activities" ON user_activities
    FOR SELECT USING (auth.uid()::text = user_id OR 
                     EXISTS (SELECT 1 FROM users_profiles WHERE id = auth.uid()::text AND role = 'admin'));

CREATE POLICY "Users can insert their own activities" ON user_activities
    FOR INSERT WITH CHECK (auth.uid()::text = user_id);

-- Policies for user_sessions
CREATE POLICY "Users can view their own sessions" ON user_sessions
    FOR SELECT USING (auth.uid()::text = user_id OR 
                     EXISTS (SELECT 1 FROM users_profiles WHERE id = auth.uid()::text AND role = 'admin'));

CREATE POLICY "Users can insert their own sessions" ON user_sessions
    FOR INSERT WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can update their own sessions" ON user_sessions
    FOR UPDATE USING (auth.uid()::text = user_id);

-- Policies for user_file_access
CREATE POLICY "Users can view their own file access" ON user_file_access
    FOR SELECT USING (auth.uid()::text = user_id OR 
                     EXISTS (SELECT 1 FROM users_profiles WHERE id = auth.uid()::text AND role = 'admin'));

CREATE POLICY "Users can insert their own file access" ON user_file_access
    FOR INSERT WITH CHECK (auth.uid()::text = user_id);

-- Policies for learning_analytics
CREATE POLICY "Users can view their own analytics" ON learning_analytics
    FOR SELECT USING (auth.uid()::text = user_id OR 
                     EXISTS (SELECT 1 FROM users_profiles WHERE id = auth.uid()::text AND role = 'admin'));

-- Admin policies (admins can do everything)
CREATE POLICY "Admins can do everything on activities" ON user_activities
    FOR ALL USING (EXISTS (SELECT 1 FROM users_profiles WHERE id = auth.uid()::text AND role = 'admin'));

CREATE POLICY "Admins can do everything on sessions" ON user_sessions
    FOR ALL USING (EXISTS (SELECT 1 FROM users_profiles WHERE id = auth.uid()::text AND role = 'admin'));

CREATE POLICY "Admins can do everything on file access" ON user_file_access
    FOR ALL USING (EXISTS (SELECT 1 FROM users_profiles WHERE id = auth.uid()::text AND role = 'admin'));

CREATE POLICY "Admins can do everything on analytics" ON learning_analytics
    FOR ALL USING (EXISTS (SELECT 1 FROM users_profiles WHERE id = auth.uid()::text AND role = 'admin'));

-- 11. Create indexes for better performance on new columns
CREATE INDEX IF NOT EXISTS idx_users_profiles_last_activity ON users_profiles(last_activity);
CREATE INDEX IF NOT EXISTS idx_users_profiles_is_active ON users_profiles(is_active);
CREATE INDEX IF NOT EXISTS idx_users_profiles_total_login_count ON users_profiles(total_login_count);

-- Grant permissions for the functions
GRANT EXECUTE ON FUNCTION update_user_session_stats TO authenticated;
GRANT EXECUTE ON FUNCTION calculate_profile_completion TO authenticated;
GRANT EXECUTE ON FUNCTION get_user_activity_summary TO authenticated;

-- Insert some sample data for testing (optional)
-- This will be executed only if the tables are empty
DO $$
BEGIN
    -- Sample activity data would be inserted by the application
    -- No need to insert sample data in migration
    NULL;
END
$$;