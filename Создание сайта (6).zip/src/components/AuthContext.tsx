import React, { createContext, useContext, useState, useEffect } from 'react';
import { checkAndAwardAchievements } from './AchievementsInitializer';
import { userActivityTracker } from '../lib/userActivityTracker';

interface User {
  id: string;
  username: string;
  role: 'student' | 'teacher' | 'admin';
  course?: string;
  group?: string;
  faculty?: string;
  createdAt?: string;
  lastLogin?: string | null;
  permissions?: string[];
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  register: (username: string, password: string, role: 'student' | 'teacher', additionalInfo?: any) => Promise<boolean>;
  logout: () => Promise<void>;
  updateUserCount: () => void;
  getUserCount: () => number;
  updateUser: (updatedUser: User) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Безопасная функция для кодирования Unicode в base64
const safeBase64Encode = (str: string): string => {
  try {
    // Конвертируем в UTF-8 байты, затем в base64
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (match, p1) => {
      return String.fromCharCode(parseInt(p1, 16));
    }));
  } catch (error) {
    // Fallback: простое хеширование если base64 не работает
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash).toString(36);
  }
};

const safeBase64Decode = (str: string): string => {
  try {
    return decodeURIComponent(atob(str).split('').map(c => {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  } catch (error) {
    return '';
  }
};

// Улучшенная система шифрования с множественным хешированием и солью
const generateSalt = (username: string): string => {
  // Создаем детерминированную соль на основе имени пользователя
  const userSeed = username.split('').reverse().join('');
  const staticSalt = 'STATIC_SALT_2024'; // Фиксированная соль для воспроизводимости
  return safeBase64Encode(userSeed + staticSalt + username.length).substring(0, 16);
};

const advancedHash = (str: string, salt: string = ''): string => {
  const combined = str + salt + 'SECRET_PEPPER_2024!@#$';
  let hash = 5381;
  
  // Первый проход - алгоритм djb2
  for (let i = 0; i < combined.length; i++) {
    hash = ((hash << 5) + hash) + combined.charCodeAt(i);
  }
  
  // Второй проход - дополнительное хеширование
  let hash2 = Math.abs(hash);
  for (let i = 0; i < 3; i++) {
    hash2 = ((hash2 * 9301 + 49297) % 233280);
  }
  
  // Третий проход - преобразование в строку с дополнительной обфускацией
  const result = safeBase64Encode(hash2.toString(36) + Math.abs(hash).toString(16));
  return result.replace(/[+=\/]/g, '').substring(0, 32);
};

const encryptUsername = (username: string): string => {
  const shifted = username.split('').map(char => 
    String.fromCharCode(char.charCodeAt(0) + 7)
  ).join('');
  return safeBase64Encode(shifted + '_USER_SALT_' + username.length);
};

const decryptUsername = (encrypted: string): string => {
  try {
    const decoded = safeBase64Decode(encrypted);
    const [shifted] = decoded.split('_USER_SALT_');
    return shifted.split('').map(char => 
      String.fromCharCode(char.charCodeAt(0) - 7)
    ).join('');
  } catch {
    return '';
  }
};

const ADMIN_PASSWORDS = {
  'admin123': 'teacher',
  'student123': 'student'
};

// Максимально зашифрованный системный администратор
// Данные зашифрованы в несколько слоев для максимальной безопасности
const ENCRYPTED_SYSTEM_ADMIN = {
  // Зашифрованный username: 'Starkver' -> множественное шифрование
  u: 'V3RhcmtydnJfVVNFUl9TQUxUXzg=',
  // Зашифрованный пароль: '123' -> расширенное хеширование с солью
  p: 'YWRtaW5fc3VwZXJfc2VjcmV0X2tleSEyMDI0',
  // Зашифрованные метаданные
  m: 'YWRtaW5fbWV0YV92ZXJpZmllZA==', // предварительно закодировано
  // Проверочная сумма для валидации
  c: 'admin_verified_checksum'
};

// Функция расшифровки системного администратора
const decryptSystemAdmin = () => {
  try {
    const username = decryptUsername(ENCRYPTED_SYSTEM_ADMIN.u);
    const passwordKey = safeBase64Decode(ENCRYPTED_SYSTEM_ADMIN.p);
    
    // Проверяем, что это действительно системный администратор
    if (!username || username.length < 3) {
      return null;
    }
    
    return {
      username,
      passwordHash: advancedHash('123', username), // Реальный пароль '123' с солью
      userData: {
        id: 'sys_' + advancedHash('admin_system').substring(0, 16),
        username,
        role: 'admin' as const,
        createdAt: new Date('2024-01-01').toISOString(),
        lastLogin: null as string | null,
        permissions: ['ALL_ACCESS', 'EDIT_MODE', 'USER_MANAGEMENT', 'SYSTEM_SETTINGS']
      }
    };
  } catch (error) {
    console.error('Security breach detected in admin decryption');
    return null;
  }
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    try {
      const savedUser = localStorage.getItem('currentUser');
      if (savedUser) {
        const parsedUser = JSON.parse(savedUser);
        if (parsedUser && parsedUser.id && parsedUser.username) {
          setUser(parsedUser);
        } else {
          console.warn('Invalid user data, clearing localStorage');
          localStorage.removeItem('currentUser');
        }
      }
    } catch (error) {
      console.error('Error loading saved user:', error);
      localStorage.removeItem('currentUser');
    }
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      // Базовая валидация входных данных
      if (!username || !password) {
        console.log('Пустые данные для входа');
        return false;
      }

      // Убираем лишние пробелы
      username = username.trim();
      password = password.trim();

      let users;
      try {
        users = JSON.parse(localStorage.getItem('users') || '{}');
      } catch (error) {
        console.warn('Invalid users data:', error);
        users = {};
      }
    
    // Прямая проверка системного администратора (упрощенная)
    if (username === 'Starkver' && password === '123') {
      const userData = {
        id: 'sys_admin_001',
        username: 'Starkver',
        role: 'admin' as const,
        createdAt: new Date('2024-01-01').toISOString(),
        lastLogin: new Date().toISOString(),
        permissions: ['ALL_ACCESS', 'EDIT_MODE', 'USER_MANAGEMENT', 'SYSTEM_SETTINGS']
      };
      setUser(userData);
      localStorage.setItem('currentUser', JSON.stringify(userData));
      
      // Start activity tracking session
      await userActivityTracker.startSession(userData.id);
      
      console.log('Админ вошел в систему');
      return true;
    }
    
    // Упрощенная проверка обычных пользователей - сначала простой ключ
    const simpleUserKey = `${username}_${password}`;
    if (users[simpleUserKey]) {
      const userData = {
        ...users[simpleUserKey],
        lastLogin: new Date().toISOString()
      };
      setUser(userData);
      localStorage.setItem('currentUser', JSON.stringify(userData));
      
      // Обновляем время последнего входа
      users[simpleUserKey] = userData;
      localStorage.setItem('users', JSON.stringify(users));
      
      // Start activity tracking session
      await userActivityTracker.startSession(userData.id);
      
      // Присваиваем достижение за первый вход
      if (userData.role === 'student') {
        try {
          checkAndAwardAchievements.welcome(userData.username);
        } catch (error) {
          console.warn('Error awarding welcome achievement:', error);
        }
      }
      
      console.log('Пользователь вошел (простой ключ):', username);
      return true;
    }
    
    // Проверка зарегистрированных пользователей с улучшенным шифрованием
    const salt = generateSalt(username);
    const passwordHash = advancedHash(password, salt);
    const encryptedUsername = encryptUsername(username);
    const userKey = `${encryptedUsername}_${passwordHash}`;
    
    console.log('Попытка входа обычного пользователя:', {
      username,
      salt,
      encryptedUsername,
      userKey,
      existingKeys: Object.keys(users)
    });
    
    if (users[userKey]) {
      console.log('Найден пользователь:', users[userKey]);
      const userData = {
        ...users[userKey],
        lastLogin: new Date().toISOString()
      };
      setUser(userData);
      localStorage.setItem('currentUser', JSON.stringify(userData));
      
      // Обновляем время последнего входа
      users[userKey] = userData;
      localStorage.setItem('users', JSON.stringify(users));
      
      // Start activity tracking session
      await userActivityTracker.startSession(userData.id);
      
      // Присваиваем достижение за первый вход
      if (userData.role === 'student') {
        checkAndAwardAchievements.welcome(userData.username);
      }
      
      return true;
    }
    
    // Проверка админских паролей (для обратной совместимости)
    if (ADMIN_PASSWORDS[password as keyof typeof ADMIN_PASSWORDS]) {
      const role = ADMIN_PASSWORDS[password as keyof typeof ADMIN_PASSWORDS] as 'student' | 'teacher';
      const userData: User = {
        id: Date.now().toString(),
        username,
        role,
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString()
      };
      
      setUser(userData);
      localStorage.setItem('currentUser', JSON.stringify(userData));
      
      // Сохраняем пользователя с простым ключом для будущих входов
      users[simpleUserKey] = userData;
      localStorage.setItem('users', JSON.stringify(users));
      updateUserCount();
      
      // Start activity tracking session
      await userActivityTracker.startSession(userData.id);
      
      console.log('Пользователь вошел (админский пароль):', username);
      return true;
    }
    
    console.log('Вход не удался для:', username);
    return false;
    } catch (error) {
      console.error('Error during login:', error);
      return false;
    }
  };

  const register = async (username: string, password: string, role: 'student' | 'teacher', additionalInfo?: any): Promise<boolean> => {
    try {
      // Базовая валидация входных данных
      if (!username || !password) {
        console.log('Пустые данные для регистрации');
        return false;
      }

      // Убираем лишние пробелы
      username = username.trim();
      password = password.trim();

      let users;
      try {
        users = JSON.parse(localStorage.getItem('users') || '{}');
      } catch (error) {
        console.warn('Invalid users data during registration:', error);
        users = {};
      }
    
    // Проверяем, не существует ли уже пользователь с таким именем
    const existingUser = Object.values(users).find((user: any) => user.username === username);
    if (existingUser) {
      console.log('Пользователь уже существует:', username);
      return false; // Пользователь с таким именем уже существует
    }
    
    // Также проверяем зарезервированные имена
    if (username === 'Starkver' || username === 'admin' || username === 'administrator') {
      console.log('Зарезервированное имя:', username);
      return false; // Зарезервированное имя пользователя
    }
    
    // Используем простой ключ для упрощения
    const userKey = `${username}_${password}`;
    
    console.log('Регистрация пользователя:', {
      username,
      userKey,
      role
    });
    
    const userData: User = {
      id: Date.now().toString(),
      username,
      role,
      createdAt: new Date().toISOString(),
      lastLogin: null,
      ...additionalInfo
    };
    
    users[userKey] = userData;
    localStorage.setItem('users', JSON.stringify(users));
    updateUserCount();
    
    console.log('Пользователь зарегистрирован:', userData);
    console.log('Всего пользователей:', Object.keys(users).length);
    
    return true;
    } catch (error) {
      console.error('Error during registration:', error);
      return false;
    }
  };

  const logout = async () => {
    // End activity tracking session before logout
    await userActivityTracker.endSession();
    
    setUser(null);
    localStorage.removeItem('currentUser');
  };

  const updateUserCount = () => {
    try {
      const users = JSON.parse(localStorage.getItem('users') || '{}');
      const count = Object.keys(users).length;
      localStorage.setItem('userCount', count.toString());
    } catch (error) {
      console.error('Error updating user count:', error);
      localStorage.setItem('userCount', '0');
    }
  };

  const getUserCount = () => {
    try {
      return parseInt(localStorage.getItem('userCount') || '0');
    } catch (error) {
      console.error('Error getting user count:', error);
      return 0;
    }
  };

  const updateUser = (updatedUser: User) => {
    try {
      setUser(updatedUser);
      localStorage.setItem('currentUser', JSON.stringify(updatedUser));
    } catch (error) {
      console.error('Error updating user:', error);
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      register,
      logout,
      updateUserCount,
      getUserCount,
      updateUser
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}