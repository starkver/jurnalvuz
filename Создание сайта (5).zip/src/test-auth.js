// Тест системы аутентификации

const generateSalt = (username) => {
  // Создаем детерминированную соль на основе имени пользователя
  const userSeed = username.split('').reverse().join('');
  const staticSalt = 'STATIC_SALT_2024'; // Фиксированная соль для воспроизводимости
  return btoa(userSeed + staticSalt + username.length).substring(0, 16);
};

const advancedHash = (str, salt = '') => {
  const combined = str + salt + 'SECRET_PEPPER_2024!@#$';
  let hash = 5381;
  
  // Первый проход - алгоритм djb2
  for (let i = 0; i < combined.length; i++) {
    hash = ((hash << 5) + hash) + combined.charCodeAt(i);
  }
  
  // Второй проход - дополнительное хеширование
  let hash2 = Math.abs(hash);
  for (let i = 0; i < 3; i++) {
    hash2 = ((hash2 * 9301 + 49297) % 233280);
  }
  
  // Третий проход - преобразование в строку с дополнительной обфускацией
  const result = btoa(hash2.toString(36) + Math.abs(hash).toString(16));
  return result.replace(/[+=\/]/g, '').substring(0, 32);
};

const encryptUsername = (username) => {
  const shifted = username.split('').map(char => 
    String.fromCharCode(char.charCodeAt(0) + 7)
  ).join('');
  return btoa(shifted + '_USER_SALT_' + username.length);
};

// Тест
const username = 'testuser';
const password = 'testpass';

const salt = generateSalt(username);
const passwordHash = advancedHash(password, salt);
const encryptedUsername = encryptUsername(username);
const userKey = `${encryptedUsername}_${passwordHash}`;

console.log('Тест регистрации и входа:');
console.log('Username:', username);
console.log('Password:', password);
console.log('Salt:', salt);
console.log('Password Hash:', passwordHash);
console.log('Encrypted Username:', encryptedUsername);
console.log('User Key:', userKey);

// Проверим, что ключи одинаковые при повторном вызове
const salt2 = generateSalt(username);
const passwordHash2 = advancedHash(password, salt2);
const encryptedUsername2 = encryptUsername(username);
const userKey2 = `${encryptedUsername2}_${passwordHash2}`;

console.log('\nПовторный тест:');
console.log('Salt 2:', salt2);
console.log('Password Hash 2:', passwordHash2);
console.log('Encrypted Username 2:', encryptedUsername2);
console.log('User Key 2:', userKey2);

console.log('\nКлючи совпадают:', userKey === userKey2);