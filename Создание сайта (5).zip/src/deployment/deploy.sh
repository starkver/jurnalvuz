#!/bin/bash

# Скрипт развертывания образовательного портала
# Запуск: sudo bash deploy.sh
#
# Если возникает ошибка "Type 'Types:' is not known", запустите:
#   sudo bash deployment/fix-sources-format.sh
# а затем повторите: sudo bash deploy.sh

set -e

echo "🚀 Начинаем развертывание образовательного портала..."

# Переменные (настройте под ваш сервер)
PROJECT_NAME="educational-portal"
DOMAIN="your-domain.com"
SERVER_PATH="/var/www/$PROJECT_NAME"
NGINX_SITES_PATH="/etc/nginx/sites-available"
BACKUP_PATH="/var/backups/$PROJECT_NAME"

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Функция логирования
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
    exit 1
}

warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

# Проверка прав root
if [ "$EUID" -ne 0 ]; then
    error "Запустите скрипт с правами root (sudo bash deploy.sh)"
fi

# Проверка репозиториев Ubuntu
log "Проверка существующих репозиториев Ubuntu..."

# Проверяем существующий sources.list
if [ -f /etc/apt/sources.list ]; then
    # Проверяем, не использует ли он новый формат DEB822
    if grep -q "^Types:" /etc/apt/sources.list 2>/dev/null; then
        warning "Обнаружен неправильный формат DEB822 в sources.list"
        log "Создаем резервную копию..."
        cp /etc/apt/sources.list /etc/apt/sources.list.backup-deb822-$(date +%Y%m%d-%H%M%S)
        
        log "Конвертируем в традиционный формат..."
        # Определяем версию Ubuntu
        UBUNTU_CODENAME=$(lsb_release -cs 2>/dev/null || echo "noble")
        
        # Создаем sources.list в правильном формате
        tee /etc/apt/sources.list > /dev/null <<EOF
# Ubuntu Main Repositories
deb http://archive.ubuntu.com/ubuntu/ ${UBUNTU_CODENAME} main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu/ ${UBUNTU_CODENAME}-updates main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu/ ${UBUNTU_CODENAME}-backports main restricted universe multiverse

# Ubuntu Security Updates
deb http://security.ubuntu.com/ubuntu/ ${UBUNTU_CODENAME}-security main restricted universe multiverse
EOF
        log "✅ Файл sources.list конвертирован в правильный формат"
    else
        log "Используем существующую конфигурацию репозиториев"
    fi
    
    log "Текущие репозитории:"
    grep -v '^#' /etc/apt/sources.list | grep -v '^$' | head -n 5 | sed 's/^/  /' || true
else
    warning "sources.list не найден, будет создан базовый"
    
    # Определяем версию Ubuntu
    UBUNTU_CODENAME=$(lsb_release -cs 2>/dev/null || echo "noble")
    
    tee /etc/apt/sources.list > /dev/null <<EOF
# Ubuntu Main Repositories
deb http://archive.ubuntu.com/ubuntu/ ${UBUNTU_CODENAME} main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu/ ${UBUNTU_CODENAME}-updates main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu/ ${UBUNTU_CODENAME}-backports main restricted universe multiverse

# Ubuntu Security Updates
deb http://security.ubuntu.com/ubuntu/ ${UBUNTU_CODENAME}-security main restricted universe multiverse
EOF
    log "✅ Создан новый sources.list в правильном формате"
fi

# Обновление списка пакетов
log "Обновление списка пакетов с существующими репозиториями..."
apt clean
apt update || error "Не удалось обновить список пакетов с текущими репозиториями"

# Обновление системы
log "Обновление системы..."
apt upgrade -y

# Установка snapd если его нет
log "Проверка snapd..."
if ! command -v snap &> /dev/null; then
    log "Установка snapd..."
    apt install -y snapd
    systemctl enable snapd
    systemctl start snapd
fi

# Установка базовых пакетов
log "Установка базовых пакетов..."
apt install -y curl wget software-properties-common gnupg lsb-release || {
    error "Не удалось установить базовые пакеты"
}

# Установка nginx
log "Установка nginx..."
if ! apt install -y nginx; then
    warning "Не удалось установить nginx через apt, пробуем через snap..."
    snap install nginx --classic || error "Не удалось установить nginx"
fi

# Установка Node.js через NodeSource репозиторий
log "Добавление репозитория NodeSource..."
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt update

log "Установка Node.js и npm..."
apt install -y nodejs || {
    warning "Не удалось установить nodejs через репозиторий, пробуем snap..."
    snap install node --classic || error "Не удалось установить nodejs"
}

# Установка certbot через snap (рекомендуемый способ)
log "Установка certbot через snap..."
snap install core
snap refresh core
snap install --classic certbot || {
    warning "Snap недоступен, пробуем apt..."
    apt install -y certbot python3-certbot-nginx || {
        warning "Certbot не установлен, SSL будет настроен вручную позже"
    }
}

# Создаем симлинк для certbot если установлен через snap
if command -v /snap/bin/certbot &> /dev/null; then
    ln -sf /snap/bin/certbot /usr/bin/certbot
fi

# Установка Node.js 18+ (если нужно)
log "Проверка версии Node.js..."
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt "18" ]; then
    warning "Обновляем Node.js до версии 18+"
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get install -y nodejs
fi

# Создание директории проекта
log "Создание директории проекта..."
mkdir -p $SERVER_PATH
mkdir -p $BACKUP_PATH

# Создание резервной копии (если проект уже существует)
if [ -d "$SERVER_PATH/dist" ]; then
    log "Создание резервной копии..."
    tar -czf "$BACKUP_PATH/backup-$(date +%Y%m%d-%H%M%S).tar.gz" -C $SERVER_PATH .
fi

# Копирование файлов проекта
log "Копирование файлов проекта..."
cp -r . $SERVER_PATH/
cd $SERVER_PATH

# Установка зависимостей
log "Установка зависимостей..."
npm install

# Сборка проекта
log "Сборка проекта для продакшена..."
npm run build

# Настройка nginx
log "Настройка nginx..."
cp deployment/nginx.conf $NGINX_SITES_PATH/$PROJECT_NAME

# Замена домена в конфигурации
sed -i "s/your-domain.com/$DOMAIN/g" $NGINX_SITES_PATH/$PROJECT_NAME

# Создание символической ссылки
ln -sf $NGINX_SITES_PATH/$PROJECT_NAME /etc/nginx/sites-enabled/

# Проверка конфигурации nginx
nginx -t || error "Ошибка в конфигурации nginx"

# Настройка SSL сертификата
log "Настройка SSL сертификата..."
if command -v certbot &> /dev/null; then
    if ! certbot certificates | grep -q "$DOMAIN"; then
        log "Получение SSL сертификата для $DOMAIN..."
        certbot --nginx -d $DOMAIN -d www.$DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN || {
            warning "Не удалось получить SSL сертификат. Продолжаем без SSL."
            warning "Для получения SSL вручную выполните: certbot --nginx -d $DOMAIN"
        }
    else
        log "SSL сертификат уже существует"
    fi
    
    # Настройка автоматического обновления SSL
    if ! crontab -l 2>/dev/null | grep -q "certbot renew"; then
        (crontab -l 2>/dev/null; echo "0 12 * * * /usr/bin/certbot renew --quiet") | crontab -
        log "Настроено автоматическое обновление SSL сертификатов"
    fi
else
    warning "Certbot не установлен. SSL сертификат нужно будет настроить вручную."
    warning "Для установки certbot выполните: snap install --classic certbot"
fi

# Настройка прав доступа
log "Настройка прав доступа..."
chown -R www-data:www-data $SERVER_PATH
chmod -R 755 $SERVER_PATH

# Настройка firewall
log "Настройка firewall..."
ufw allow 'Nginx Full'
ufw allow OpenSSH
ufw --force enable

# Перезапуск nginx
log "Перезапуск nginx..."
systemctl restart nginx
systemctl enable nginx

# Проверка статуса
log "Проверка статуса сервисов..."
systemctl is-active --quiet nginx && log "✓ Nginx запущен" || error "✗ Nginx не запущен"

log "🎉 Развертывание завершено успешно!"
log "🌐 Ваш сайт доступен по адресу: https://$DOMAIN"
log "📋 Логи nginx: /var/log/nginx/"
log "📁 Файлы проекта: $SERVER_PATH"
log "🔄 Для обновления сайта запустите: npm run build в $SERVER_PATH"

echo ""
echo "📝 Дополнительные команды:"
echo "   Просмотр логов nginx: sudo tail -f /var/log/nginx/access.log"
echo "   Перезапуск nginx: sudo systemctl restart nginx"
echo "   Обновление SSL: sudo certbot renew"
echo "   Проверка статуса: sudo systemctl status nginx"