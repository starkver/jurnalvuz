import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { BookOpen, Users, Award, Calendar } from "lucide-react";

export function HomeSection() {
  const features = [
    {
      icon: <BookOpen className="h-8 w-8 text-primary" />,
      title: "Образовательные материалы",
      description: "Полный набор учебных материалов для 1 и 2 курса"
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: "Поддержка студентов",
      description: "Помощь и консультации по всем учебным вопросам"
    },
    {
      icon: <Award className="h-8 w-8 text-primary" />,
      title: "Система оценок",
      description: "Отслеживание успеваемости и достижений"
    },
    {
      icon: <Calendar className="h-8 w-8 text-primary" />,
      title: "Расписание",
      description: "Актуальное расписание занятий и экзаменов"
    }
  ];

  const announcements = [
    {
      title: "Начало нового семестра",
      date: "15 сентября 2024",
      description: "Добро пожаловать в новый учебный семестр! Ознакомьтесь с обновленными материалами курса.",
      badge: "Важно"
    },
    {
      title: "Обновление материалов 1 курса",
      date: "10 сентября 2024", 
      description: "Добавлены новые лекции и практические задания для первого курса.",
      badge: "Обновление"
    },
    {
      title: "Экзаменационная сессия",
      date: "1 декабря 2024",
      description: "Подготовка к зимней экзаменационной сессии. Расписание экзаменов доступно в разделе курсов.",
      badge: "Экзамены"
    }
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="text-center py-12 px-4">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Добро пожаловать в
          <span className="text-primary block">Образовательный портал</span>
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
          Ваш путь к знаниям начинается здесь. Изучайте материалы курсов, 
          отслеживайте прогресс и достигайте новых высот в образовании.
        </p>
      </section>

      {/* Features Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 px-4">
        {features.map((feature, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader className="text-center pb-4">
              <div className="mx-auto mb-4">
                {feature.icon}
              </div>
              <CardTitle className="text-lg">{feature.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                {feature.description}
              </CardDescription>
            </CardContent>
          </Card>
        ))}
      </section>

      {/* Announcements */}
      <section className="px-4">
        <h2 className="text-2xl font-bold mb-6">Объявления</h2>
        <div className="space-y-4">
          {announcements.map((announcement, index) => (
            <Card key={index}>
              <CardHeader>
                <div className="flex justify-between items-start flex-wrap gap-2">
                  <CardTitle className="text-lg">{announcement.title}</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{announcement.badge}</Badge>
                    <span className="text-sm text-muted-foreground">{announcement.date}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>{announcement.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Quick Stats */}
      <section className="bg-muted/50 rounded-lg p-8 mx-4">
        <h2 className="text-2xl font-bold text-center mb-8">Статистика портала</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-3xl font-bold text-primary">150+</div>
            <div className="text-muted-foreground">Студентов</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-primary">25</div>
            <div className="text-muted-foreground">Предметов</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-primary">500+</div>
            <div className="text-muted-foreground">Материалов</div>
          </div>
        </div>
      </section>
    </div>
  );
}