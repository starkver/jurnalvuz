import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Alert, AlertDescription } from "./ui/alert";
import { Separator } from "./ui/separator";
import { 
  Edit, Save, Plus, Trash2, Eye, EyeOff, 
  Home, Building, HelpCircle, Gift, 
  FileText, Monitor, Palette 
} from "lucide-react";
import { toast } from "../lib/toast";

export function AdminContentManager() {
  const [activeSection, setActiveSection] = useState("main");
  const [editingData, setEditingData] = useState("");
  const [newSectionName, setNewSectionName] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");

  // Получение данных секции из localStorage
  const getSectionData = (sectionKey: string) => {
    const data = localStorage.getItem(sectionKey);
    return data ? JSON.parse(data) : {};
  };

  // Сохранение данных секции
  const saveSectionData = (sectionKey: string, data: any) => {
    localStorage.setItem(sectionKey, JSON.stringify(data));
    toast.success("Изменения сохранены");
  };

  // Загрузка данных для редактирования
  const loadSectionForEdit = (sectionKey: string) => {
    const data = getSectionData(sectionKey);
    setEditingData(JSON.stringify(data, null, 2));
    setActiveSection(sectionKey);
  };

  // Сохранение изменений
  const saveChanges = () => {
    try {
      const parsedData = JSON.parse(editingData);
      saveSectionData(activeSection, parsedData);
    } catch (error) {
      toast.error("Ошибка в JSON формате");
    }
  };

  // Создание новой секции
  const createNewSection = () => {
    if (!newSectionName.trim()) {
      toast.error("Введите название секции");
      return;
    }
    
    const sectionKey = `admin_section_${newSectionName.toLowerCase().replace(/\s+/g, '_')}`;
    const defaultData = getTemplateData(selectedTemplate, newSectionName);
    
    saveSectionData(sectionKey, defaultData);
    setNewSectionName("");
    setSelectedTemplate("");
    loadSectionForEdit(sectionKey);
  };

  // Шаблоны для новых секций
  const getTemplateData = (template: string, title: string) => {
    const templates = {
      page: {
        title,
        content: `# ${title}\n\nНовая страница с содержимым.`,
        type: "page",
        visible: true,
        created: new Date().toISOString()
      },
      info_block: {
        title,
        description: "Описание информационного блока",
        items: [
          { title: "Пункт 1", content: "Содержимое пункта 1" },
          { title: "Пункт 2", content: "Содержимое пункта 2" }
        ],
        type: "info_block",
        visible: true,
        created: new Date().toISOString()
      },
      faq: {
        title,
        questions: [
          { question: "Вопрос 1?", answer: "Ответ на вопрос 1" },
          { question: "Вопрос 2?", answer: "Ответ на вопрос 2" }
        ],
        type: "faq",
        visible: true,
        created: new Date().toISOString()
      }
    };
    
    return templates[template as keyof typeof templates] || templates.page;
  };

  // Получение всех секций
  const getAllSections = () => {
    const sections = [
      { key: "main_page", title: "Главная страница", icon: Home },
      { key: "campuses", title: "Корпуса", icon: Building },
      { key: "faq", title: "FAQ", icon: HelpCircle },
      { key: "benefits", title: "Льготы", icon: Gift },
      { key: "announcements", title: "Объявления", icon: FileText },
      { key: "events", title: "События", icon: Monitor }
    ];

    // Добавляем пользовательские секции
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('admin_section_')) {
        const data = getSectionData(key);
        sections.push({
          key,
          title: data.title || key.replace('admin_section_', ''),
          icon: FileText
        });
      }
    }

    return sections;
  };

  // Удаление секции
  const deleteSection = (sectionKey: string) => {
    if (confirm("Вы уверены, что хотите удалить эту секцию?")) {
      localStorage.removeItem(sectionKey);
      toast.success("Секция удалена");
      if (activeSection === sectionKey) {
        setActiveSection("main_page");
        setEditingData("");
      }
    }
  };

  // Экспорт настроек
  const exportSettings = () => {
    const settings: any = {};
    getAllSections().forEach(section => {
      settings[section.key] = getSectionData(section.key);
    });
    
    const blob = new Blob([JSON.stringify(settings, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `site-settings-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Настройки экспортированы");
  };

  // Импорт настроек
  const importSettings = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const settings = JSON.parse(e.target?.result as string);
        Object.entries(settings).forEach(([key, value]) => {
          localStorage.setItem(key, JSON.stringify(value));
        });
        toast.success("Настройки импортированы");
      } catch (error) {
        toast.error("Ошибка при импорте файла");
      }
    };
    reader.readAsText(file);
  };

  const sections = getAllSections();

  return (
    <div className="space-y-6">
      <div className="text-center py-4">
        <h2 className="text-2xl mb-2">Управление контентом сайта</h2>
        <p className="text-muted-foreground">
          Редактируйте содержимое всех разделов сайта
        </p>
      </div>

      <Tabs defaultValue="editor" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="editor">Редактор контента</TabsTrigger>
          <TabsTrigger value="create">Создать раздел</TabsTrigger>
          <TabsTrigger value="settings">Настройки</TabsTrigger>
        </TabsList>

        <TabsContent value="editor" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Список секций */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Разделы сайта
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {sections.map((section) => {
                  const IconComponent = section.icon;
                  return (
                    <div
                      key={section.key}
                      className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-colors ${
                        activeSection === section.key 
                          ? 'border-primary bg-primary/5' 
                          : 'hover:bg-accent'
                      }`}
                      onClick={() => loadSectionForEdit(section.key)}
                    >
                      <div className="flex items-center gap-2">
                        <IconComponent className="h-4 w-4" />
                        <span className="text-sm font-medium">{section.title}</span>
                      </div>
                      {section.key.startsWith('admin_section_') && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteSection(section.key);
                          }}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Редактор */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Edit className="h-5 w-5" />
                    Редактор: {sections.find(s => s.key === activeSection)?.title || "Выберите раздел"}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {activeSection ? (
                    <>
                      <div>
                        <Label>JSON данные раздела:</Label>
                        <Textarea
                          value={editingData}
                          onChange={(e) => setEditingData(e.target.value)}
                          rows={20}
                          className="font-mono text-sm"
                          placeholder="Выберите раздел для редактирования..."
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={saveChanges} className="flex-1">
                          <Save className="h-4 w-4 mr-2" />
                          Сохранить изменения
                        </Button>
                        <Button 
                          variant="outline" 
                          onClick={() => loadSectionForEdit(activeSection)}
                        >
                          Сбросить
                        </Button>
                      </div>
                    </>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      Выберите раздел для редактирования из списка слева
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="create" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Создать новый раздел
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Название раздела:</Label>
                <Input
                  value={newSectionName}
                  onChange={(e) => setNewSectionName(e.target.value)}
                  placeholder="Например: Дополнительная информация"
                />
              </div>
              
              <div>
                <Label>Шаблон:</Label>
                <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите шаблон" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="page">Обычная страница</SelectItem>
                    <SelectItem value="info_block">Информационный блок</SelectItem>
                    <SelectItem value="faq">FAQ раздел</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={createNewSection} className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Создать раздел
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="h-5 w-5" />
                  Экспорт/Импорт настроек
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Экспорт всех настроек сайта:</Label>
                  <Button onClick={exportSettings} variant="outline" className="w-full mt-2">
                    Скачать backup.json
                  </Button>
                </div>
                
                <Separator />
                
                <div>
                  <Label>Импорт настроек:</Label>
                  <input
                    type="file"
                    accept=".json"
                    onChange={importSettings}
                    className="mt-2 block w-full text-sm text-foreground
                      file:mr-4 file:py-2 file:px-4
                      file:rounded-lg file:border-0
                      file:text-sm file:font-medium
                      file:bg-primary file:text-primary-foreground
                      hover:file:bg-primary/90"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Дополнительные инструменты
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button variant="outline" className="w-full">
                  <Eye className="h-4 w-4 mr-2" />
                  Предпросмотр сайта
                </Button>
                
                <Button variant="outline" className="w-full">
                  <FileText className="h-4 w-4 mr-2" />
                  Генерация отчета
                </Button>

                <Alert>
                  <FileText className="h-4 w-4" />
                  <AlertDescription>
                    Все изменения сохраняются в localStorage браузера. 
                    Регулярно создавайте резервные копии.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}