import { useState } from "react";
import { MarkdownFileViewer } from "./MarkdownFileViewer";

export function SimpleCourse1Section() {
  const [activeTab, setActiveTab] = useState("subjects");

  const subjects = [
    {
      id: "math",
      name: "Математика", 
      progress: 75,
      totalLessons: 24,
      completedLessons: 18,
      description: "Основы высшей математики, алгебра и геометрия"
    },
    {
      id: "programming",
      name: "Программирование",
      progress: 60,
      totalLessons: 30,
      completedLessons: 18,
      description: "Введение в программирование на Python и основы алгоритмов"
    },
    {
      id: "physics",
      name: "Физика",
      progress: 85,
      totalLessons: 20,
      completedLessons: 17,
      description: "Механика, термодинамика и основы электричества"
    },
    {
      id: "english",
      name: "Английский язык",
      progress: 90,
      totalLessons: 16,
      completedLessons: 14,
      description: "Общий английский и техническая терминология"
    }
  ];

  const recentMaterials = [
    {
      title: "Лекция: Производные и интегралы",
      subject: "Математика",
      type: "📹",
      date: "20 сентября",
      duration: "45 мин"
    },
    {
      title: "Практическое задание: Циклы в Python",
      subject: "Программирование",
      type: "📄",
      date: "18 сентября", 
      duration: "2 часа"
    },
    {
      title: "Конспект: Законы Ньютона",
      subject: "Физика",
      type: "📚",
      date: "15 сентября",
      duration: "30 мин"
    }
  ];

  const assignments = [
    {
      title: "Контрольная работа по математике",
      subject: "Математика",
      deadline: "30 сентября",
      status: "pending"
    },
    {
      title: "Проект: Калькулятор",
      subject: "Программирование",
      deadline: "5 октября",
      status: "in-progress"
    },
    {
      title: "Лабораторная работа: Механика", 
      subject: "Физика",
      deadline: "25 сентября",
      status: "completed"
    }
  ];

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'completed': return { label: "✅ Выполнено", color: "bg-green-100 text-green-800" };
      case 'in-progress': return { label: "🕒 В процессе", color: "bg-yellow-100 text-yellow-800" };
      case 'pending': return { label: "⏳ Ожидает", color: "bg-gray-100 text-gray-800" };
      default: return { label: status, color: "bg-gray-100 text-gray-800" };
    }
  };

  const tabs = [
    { id: "subjects", label: "Предметы" },
    { id: "materials", label: "Материалы" },
    { id: "assignments", label: "Задания" },
    { id: "markdown", label: "Загрузить .md" }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-gray-100">1 курс</h1>
        <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
          Изучайте основные предметы первого курса, отслеживайте прогресс и выполняйте задания
        </p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="flex space-x-8 px-4">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? "border-blue-500 text-blue-600 dark:text-blue-400"
                  : "border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600"
              }`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === "subjects" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-4">
          {subjects.map((subject) => (
            <div key={subject.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-shadow p-6">
              <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-gray-100">{subject.name}</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">{subject.description}</p>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600 dark:text-gray-300">Прогресс</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-gray-100">{subject.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-blue-600 dark:bg-blue-500 h-2 rounded-full" 
                    style={{ width: `${subject.progress}%` }}
                  ></div>
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-300">
                  {subject.completedLessons} из {subject.totalLessons} уроков
                </div>
                <button className="w-full py-2 px-4 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                  Перейти к предмету
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === "materials" && (
        <div className="space-y-4 px-4">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Последние материалы</h2>
          {recentMaterials.map((material, index) => (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className="text-2xl">{material.type}</div>
                  <div className="space-y-1">
                    <h3 className="font-medium text-gray-900 dark:text-gray-100">{material.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300">{material.subject}</p>
                    <div className="flex items-center space-x-4 text-xs text-gray-500 dark:text-gray-400">
                      <span>{material.date}</span>
                      <span>•</span>
                      <span>{material.duration}</span>
                    </div>
                  </div>
                </div>
                <button className="p-2 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300">
                  ⬇️
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === "assignments" && (
        <div className="space-y-4 px-4">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Задания и проекты</h2>
          {assignments.map((assignment, index) => {
            const statusInfo = getStatusInfo(assignment.status);
            return (
              <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <h3 className="font-medium text-gray-900 dark:text-gray-100">{assignment.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300">{assignment.subject}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Срок сдачи: {assignment.deadline}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 rounded-full text-xs ${statusInfo.color}`}>
                      {statusInfo.label}
                    </span>
                    <button className="py-1 px-3 border border-gray-300 dark:border-gray-600 rounded-md text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
                      Открыть
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {activeTab === "markdown" && (
        <div className="px-4">
          <MarkdownFileViewer />
        </div>
      )}
    </div>
  );
}