import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Building2, MapPin, Clock, Phone, Navigation, Bus } from 'lucide-react';

interface Campus {
  id: string;
  name: string;
  address: string;
  description: string;
  facilities: string[];
  workingHours: string;
  phone: string;
  imageUrl: string;
  coordinates: string;
  transportInfo: string[];
}

const campusesData: Campus[] = [
  {
    id: 'main',
    name: 'Главный корпус',
    address: 'ул. Медицинская, 12, Москва',
    description: 'Основной учебный корпус с современными аудиториями, административными помещениями и деканатами всех факультетов.',
    facilities: ['Аудитории', 'Деканаты', 'Администрация', 'Столовая', 'Кафе', 'Актовый зал'],
    workingHours: '8:00 - 20:00',
    phone: '+7 (495) 123-45-67',
    imageUrl: 'https://images.unsplash.com/photo-1633111158162-a4835dce7d0d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwdW5pdmVyc2l0eSUyMGJ1aWxkaW5nJTIwY2FtcHVzfGVufDF8fHx8MTc1ODczNjU0Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    coordinates: '55.7558, 37.6173',
    transportInfo: ['Метро: Сокольники (5 мин пешком)', 'Автобус: 40, 107, 265', 'Трамвай: 7, 37']
  },
  {
    id: 'lab',
    name: 'Лабораторный корпус',
    address: 'ул. Лабораторная, 8, Москва',
    description: 'Современный корпус с оборудованными лабораториями для практических занятий по всем медицинским дисциплинам.',
    facilities: ['Анатомические лаборатории', 'Химические лаборатории', 'Микроскопические залы', 'Компьютерные классы'],
    workingHours: '9:00 - 18:00',
    phone: '+7 (495) 123-45-68',
    imageUrl: 'https://images.unsplash.com/photo-1576669801838-1b1c52121e6a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwbGFib3JhdG9yeSUyMHVuaXZlcnNpdHklMjBlcXVpcG1lbnR8ZW58MXx8fHwxNzU4NzM2NTUyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    coordinates: '55.7468, 37.6203',
    transportInfo: ['Метро: Красносельская (7 мин пешком)', 'Автобус: 122, 140', 'Троллейбус: 14, 41']
  },
  {
    id: 'library',
    name: 'Библиотечный корпус',
    address: 'ул. Научная, 15, Москва',
    description: 'Центральная библиотека университета с обширным фондом медицинской литературы и современными читальными залами.',
    facilities: ['Читальные залы', 'Компьютерный зал', 'Архив', 'Копировальный центр', 'Зона отдыха'],
    workingHours: '8:30 - 21:00',
    phone: '+7 (495) 123-45-69',
    imageUrl: 'https://images.unsplash.com/photo-1660128355371-527b6c5f8b2f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwbGlicmFyeSUyMG1lZGljYWwlMjBlZHVjYXRpb258ZW58MXx8fHwxNzU4NzM2NTQ5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    coordinates: '55.7601, 37.6085',
    transportInfo: ['Метро: Чистые пруды (10 мин пешком)', 'Автобус: 101, 132', 'Маршрутка: 406м']
  }
];

const courseBuildings = {
  '1': {
    title: '1 курс',
    buildings: ['Главный корпус', 'Библиотечный корпус'],
    description: 'Первокурсники в основном занимаются в главном корпусе и пользуются библиотекой для самостоятельной работы.'
  },
  '2': {
    title: '2 курс', 
    buildings: ['Главный корпус', 'Лабораторный корпус', 'Библиотечный корпус'],
    description: 'Второкурсники начинают практические занятия в лабораторном корпусе, продолжая теоретическое обучение.'
  },
  '3': {
    title: '3 курс',
    buildings: ['Лабораторный корпус', 'Главный корпус'],
    description: 'Студенты третьего курса больше времени проводят в лабораториях, изучая клинические дисциплины.'
  }
};

export function CampusesSection() {
  const openMap = (coordinates: string, name: string) => {
    const url = `https://yandex.ru/maps/?text=${encodeURIComponent(name)}&ll=${coordinates}&z=16`;
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Корпуса университета</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Подробная информация о корпусах, адресах и маршрутах
        </p>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">Все корпуса</TabsTrigger>
          <TabsTrigger value="1">1 курс</TabsTrigger>
          <TabsTrigger value="2">2 курс</TabsTrigger>
          <TabsTrigger value="3">3 курс</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {campusesData.map((campus) => (
              <Card key={campus.id} className="overflow-hidden">
                <div className="relative h-48 w-full">
                  <ImageWithFallback
                    src={campus.imageUrl}
                    alt={campus.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2">
                    <Badge variant="secondary">{campus.name}</Badge>
                  </div>
                </div>
                
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="h-5 w-5" />
                    {campus.name}
                  </CardTitle>
                  <CardDescription className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    {campus.address}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <p className="text-sm">{campus.description}</p>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-blue-600" />
                      <span className="text-sm">Часы работы: {campus.workingHours}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-green-600" />
                      <span className="text-sm">{campus.phone}</span>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Помещения:</h4>
                    <div className="flex flex-wrap gap-1">
                      {campus.facilities.map((facility, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {facility}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2 flex items-center gap-1">
                      <Bus className="h-4 w-4" />
                      Транспорт:
                    </h4>
                    <ul className="text-sm space-y-1">
                      {campus.transportInfo.map((transport, index) => (
                        <li key={index} className="text-gray-600 dark:text-gray-400">
                          • {transport}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={() => openMap(campus.coordinates, campus.name)}
                  >
                    <Navigation className="mr-2 h-4 w-4" />
                    Открыть на карте
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {Object.entries(courseBuildings).map(([course, info]) => (
          <TabsContent key={course} value={course} className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{info.title}</CardTitle>
                <CardDescription>{info.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Основные корпуса для обучения:</h4>
                    <div className="flex flex-wrap gap-2">
                      {info.buildings.map((building, index) => (
                        <Badge key={index} variant="default">
                          {building}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {campusesData
                .filter(campus => info.buildings.includes(campus.name))
                .map((campus) => (
                  <Card key={campus.id} className="overflow-hidden">
                    <div className="relative h-48 w-full">
                      <ImageWithFallback
                        src={campus.imageUrl}
                        alt={campus.name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-2 right-2">
                        <Badge variant="secondary">{campus.name}</Badge>
                      </div>
                    </div>
                    
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Building2 className="h-5 w-5" />
                        {campus.name}
                      </CardTitle>
                      <CardDescription className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {campus.address}
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-blue-600" />
                          <span className="text-sm">Часы работы: {campus.workingHours}</span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-green-600" />
                          <span className="text-sm">{campus.phone}</span>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium mb-2 flex items-center gap-1">
                          <Bus className="h-4 w-4" />
                          Как добраться:
                        </h4>
                        <ul className="text-sm space-y-1">
                          {campus.transportInfo.map((transport, index) => (
                            <li key={index} className="text-gray-600 dark:text-gray-400">
                              • {transport}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <Button 
                        variant="outline" 
                        className="w-full" 
                        onClick={() => openMap(campus.coordinates, campus.name)}
                      >
                        <Navigation className="mr-2 h-4 w-4" />
                        Открыть на карте
                      </Button>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}