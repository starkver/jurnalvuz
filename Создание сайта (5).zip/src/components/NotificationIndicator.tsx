import { useState, useEffect } from "react";
import { useAuth } from "./AuthContext";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Bell } from "lucide-react";
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from "./ui/popover";
import { UserNotificationDisplay } from "./UserNotificationDisplay";

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  targetUsers: 'all' | 'students' | 'teachers' | 'specific';
  specificUsers?: string[];
  expiryDate?: string;
  createdAt: string;
  createdBy: string;
  isActive: boolean;
}

interface UserNotificationState {
  dismissed: string[];
  lastChecked: string;
}

export function NotificationIndicator() {
  const { user } = useAuth();
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (!user) {
      setUnreadCount(0);
      return;
    }

    updateUnreadCount();
    
    // Обновляем каждые 30 секунд
    const interval = setInterval(updateUnreadCount, 30000);
    
    return () => clearInterval(interval);
  }, [user]);

  const updateUnreadCount = () => {
    if (!user) return;

    try {
      // Загружаем уведомления
      const stored = localStorage.getItem('adminNotifications');
      if (!stored) {
        setUnreadCount(0);
        return;
      }

      const allNotifications: Notification[] = JSON.parse(stored);
      const userState: UserNotificationState = JSON.parse(
        localStorage.getItem(`userNotificationState_${user.username}`) || 
        '{"dismissed": [], "lastChecked": "2020-01-01T00:00:00.000Z"}'
      );

      // Фильтруем уведомления для пользователя
      const userNotifications = filterNotificationsForUser(allNotifications);
      
      // Считаем непрочитанные
      const unread = userNotifications.filter(notification => {
        return !userState.dismissed.includes(notification.id) &&
               new Date(notification.createdAt) > new Date(userState.lastChecked);
      });

      setUnreadCount(unread.length);
    } catch (error) {
      console.error('Error updating unread count:', error);
      setUnreadCount(0);
    }
  };

  const filterNotificationsForUser = (allNotifications: Notification[]): Notification[] => {
    if (!user) return [];

    const now = new Date();
    
    return allNotifications.filter(notification => {
      // Проверяем активность
      if (!notification.isActive) return false;
      
      // Проверяем срок действия
      if (notification.expiryDate && new Date(notification.expiryDate) < now) {
        return false;
      }
      
      // Проверяем целевую аудиторию
      if (notification.targetUsers === 'all') return true;
      if (notification.targetUsers === 'students' && user.role === 'student') return true;
      if (notification.targetUsers === 'teachers' && user.role === 'teacher') return true;
      if (notification.targetUsers === 'specific' && 
          notification.specificUsers?.includes(user.username)) return true;
      
      return false;
    });
  };

  // Обновляем счетчик при открытии/закрытии поповера
  const handleOpenChange = (open: boolean) => {
    setIsOpen(open);
    if (open) {
      // При открытии сразу обнуляем счетчик, так как уведомления будут отмечены как прочитанные
      setUnreadCount(0);
    } else {
      // При закрытии обновляем счетчик на случай изменений
      setTimeout(updateUnreadCount, 100);
    }
  };

  if (!user) return null;

  return (
    <Popover open={isOpen} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge 
              className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs bg-red-500 text-white border-0"
            >
              {unreadCount > 99 ? '99+' : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 max-h-96 overflow-y-auto p-0">
        <div className="p-4">
          <UserNotificationDisplay />
        </div>
      </PopoverContent>
    </Popover>
  );
}