import { useState, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { BookOpen, FileText, Video, Download, Clock, CheckCircle, Star, TrendingUp, Upload, Share2, Trash2 } from "lucide-react";
import { MarkdownFileViewer } from "./MarkdownFileViewer";
import { useAuth } from "./AuthContext";

interface UserFile {
  id: string;
  name: string;
  content: string;
  uploadedAt: string;
  sharedWith: 'none' | 'all' | 'specific';
  sharedBy?: string;
}

export function Course2Section() {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [userFiles, setUserFiles] = useState<UserFile[]>(() => {
    const saved = localStorage.getItem(`course2_files_${user?.id}`);
    return saved ? JSON.parse(saved) : [];
  });
  const [sharedFiles, setSharedFiles] = useState<UserFile[]>(() => {
    const saved = localStorage.getItem('course2_shared_files');
    return saved ? JSON.parse(saved) : [];
  });

  const subjects = [
    {
      id: "pathology",
      name: "Патологическая анатомия",
      progress: 65,
      totalLessons: 28,
      completedLessons: 18,
      description: "Изучение болезненных изменений в органах и тканях",
      difficulty: "Высокая"
    },
    {
      id: "pathophysiology",
      name: "Патологическая физиология",
      progress: 80,
      totalLessons: 32,
      completedLessons: 26,
      description: "Механизмы развития болезней и патологических процессов",
      difficulty: "Высокая"
    },
    {
      id: "pharmacology",
      name: "Фармакология",
      progress: 70,
      totalLessons: 24,
      completedLessons: 17,
      description: "Изучение лекарственных средств и их действия на организм",
      difficulty: "Средняя"
    },
    {
      id: "microbiology",
      name: "Микробиология",
      progress: 55,
      totalLessons: 26,
      completedLessons: 14,
      description: "Изучение микроорганизмов и их роли в патологии",
      difficulty: "Средняя"
    }
  ];

  const projects = [
    {
      title: "Клинический случай: Диагностика заболевания",
      subject: "Патологическая анатомия",
      type: "Курсовой проект",
      deadline: "15 декабря",
      status: "in-progress",
      description: "Анализ и интерпретация клинического случая с патоморфологическими изменениями"
    },
    {
      title: "Исследование механизмов воспаления",
      subject: "Патологическая физиология",
      type: "Практический проект",
      deadline: "30 октября",
      status: "completed",
      description: "Экспериментальное изучение процессов острого воспаления"
    },
    {
      title: "Фармакологический анализ препаратов",
      subject: "Фармакология",
      type: "Лабораторная работа",
      deadline: "20 ноября",
      status: "pending",
      description: "Сравнительный анализ эффективности различных групп препаратов"
    }
  ];

  const achievements = [
    {
      title: "Отличник семестра",
      description: "Средний балл выше 4.5",
      earned: true
    },
    {
      title: "Лучший клинический случай",
      description: "Проект получил наивысшую оценку",
      earned: true  
    },
    {
      title: "Активный исследователь",
      description: "Участие во всех лабораторных работах",
      earned: false
    }
  ];

  const upcomingExams = [
    {
      subject: "Патологическая анатомия",
      date: "5 декабря",
      type: "Экзамен",
      duration: "3 часа"
    },
    {
      subject: "Патологическая физиология", 
      date: "10 декабря",
      type: "Экзамен",
      duration: "2.5 часа"
    },
    {
      subject: "Фармакология",
      date: "15 декабря", 
      type: "Зачет",
      duration: "1.5 часа"
    }
  ];

  const saveUserFiles = (files: UserFile[]) => {
    setUserFiles(files);
    localStorage.setItem(`course2_files_${user?.id}`, JSON.stringify(files));
  };

  const saveSharedFiles = (files: UserFile[]) => {
    setSharedFiles(files);
    localStorage.setItem('course2_shared_files', JSON.stringify(files));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.name.endsWith('.md')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        const newFile: UserFile = {
          id: Date.now().toString(),
          name: file.name,
          content,
          uploadedAt: new Date().toISOString(),
          sharedWith: 'none'
        };
        saveUserFiles([...userFiles, newFile]);
      };
      reader.readAsText(file);
    }
  };

  const shareFile = (fileId: string, shareType: 'all' | 'specific') => {
    const file = userFiles.find(f => f.id === fileId);
    if (file && shareType === 'all') {
      const sharedFile: UserFile = {
        ...file,
        sharedWith: 'all',
        sharedBy: user?.username
      };
      saveSharedFiles([...sharedFiles, sharedFile]);
      
      const updatedUserFiles = userFiles.map(f => 
        f.id === fileId ? { ...f, sharedWith: 'all' } : f
      );
      saveUserFiles(updatedUserFiles);
    }
  };

  const deleteFile = (fileId: string) => {
    const updatedFiles = userFiles.filter(f => f.id !== fileId);
    saveUserFiles(updatedFiles);
  };

  const allFiles = [
    ...userFiles.map(f => ({ ...f, isOwn: true })),
    ...sharedFiles.filter(f => !userFiles.some(uf => uf.name === f.name))
      .map(f => ({ ...f, isOwn: false }))
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Высокая': return 'bg-red-500';
      case 'Средняя': return 'bg-yellow-500';
      case 'Низкая': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed': return <Badge variant="default" className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />Завершено</Badge>;
      case 'in-progress': return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />В работе</Badge>;
      case 'pending': return <Badge variant="outline">Ожидает</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">2 курс - Клинические дисциплины</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Углубленное изучение клинических дисциплин и работа над исследовательскими проектами
        </p>
      </div>

      <Tabs defaultValue="subjects" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="subjects">Предметы</TabsTrigger>
          <TabsTrigger value="projects">Проекты</TabsTrigger>
          <TabsTrigger value="exams">Экзамены</TabsTrigger>
          <TabsTrigger value="achievements">Достижения</TabsTrigger>
          <TabsTrigger value="files">Материалы</TabsTrigger>
        </TabsList>

        <TabsContent value="subjects" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {subjects.map((subject) => (
              <Card key={subject.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-xl">{subject.name}</CardTitle>
                      <CardDescription className="mt-2">{subject.description}</CardDescription>
                    </div>
                    <Badge variant="outline" className="ml-2">
                      <div className={`w-2 h-2 rounded-full ${getDifficultyColor(subject.difficulty)} mr-1`}></div>
                      {subject.difficulty}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Прогресс</span>
                      <span className="text-sm font-medium">{subject.progress}%</span>
                    </div>
                    <Progress value={subject.progress} className="h-2" />
                  </div>
                  <div className="flex justify-between items-center text-sm text-muted-foreground">
                    <span>{subject.completedLessons} из {subject.totalLessons} занятий</span>
                    <TrendingUp className="h-4 w-4" />
                  </div>
                  <Button className="w-full" variant="outline">
                    Перейти к предмету
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="projects" className="space-y-6">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Курсовые и исследовательские проекты</h2>
            {projects.map((project, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{project.title}</CardTitle>
                      <CardDescription className="mt-1">{project.subject} • {project.type}</CardDescription>
                    </div>
                    {getStatusBadge(project.status)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{project.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Срок сдачи: {project.deadline}</span>
                    <Button size="sm">Открыть проект</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="exams" className="space-y-6">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Предстоящие экзамены</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {upcomingExams.map((exam, index) => (
                <Card key={index}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">{exam.subject}</CardTitle>
                    <Badge variant={exam.type === 'Экзамен' ? 'default' : 'secondary'}>
                      {exam.type}
                    </Badge>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Дата</span>
                      <span className="font-medium">{exam.date}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Продолжительность</span>
                      <span className="font-medium">{exam.duration}</span>
                    </div>
                    <Button className="w-full mt-4" variant="outline" size="sm">
                      Подготовиться
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-6">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Достижения и награды</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {achievements.map((achievement, index) => (
                <Card key={index} className={achievement.earned ? "border-yellow-200 bg-yellow-50/50" : ""}>
                  <CardHeader className="text-center pb-3">
                    <div className={`mx-auto mb-2 ${achievement.earned ? 'text-yellow-500' : 'text-gray-400'}`}>
                      <Star className="h-8 w-8" fill={achievement.earned ? 'currentColor' : 'none'} />
                    </div>
                    <CardTitle className="text-lg">{achievement.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <CardDescription>{achievement.description}</CardDescription>
                    <Badge 
                      className="mt-3" 
                      variant={achievement.earned ? "default" : "outline"}
                    >
                      {achievement.earned ? "Получено" : "Не получено"}
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="files" className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Учебные материалы</h2>
              <div className="flex gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept=".md"
                  style={{ display: 'none' }}
                />
                <Button onClick={() => fileInputRef.current?.click()}>
                  <Upload className="h-4 w-4 mr-2" />
                  Загрузить файл
                </Button>
              </div>
            </div>
            
            {allFiles.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 dark:text-gray-400 mb-2">
                    Файлы не найдены
                  </h3>
                  <p className="text-gray-500 dark:text-gray-500 mb-4">
                    Загрузите первый Markdown файл для начала работы
                  </p>
                  <Button onClick={() => fileInputRef.current?.click()}>
                    <Upload className="h-4 w-4 mr-2" />
                    Загрузить файл
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {allFiles.map((file) => (
                  <Card key={file.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4">
                          <div className="p-2 bg-primary/10 rounded-lg">
                            <FileText className="h-4 w-4" />
                          </div>
                          <div className="space-y-1">
                            <h3 className="font-medium">{file.name}</h3>
                            <div className="flex items-center space-x-2">
                              {file.sharedBy && (
                                <Badge variant="secondary" className="text-xs">
                                  Поделился: {file.sharedBy}
                                </Badge>
                              )}
                              {file.isOwn && file.sharedWith === 'all' && (
                                <Badge variant="outline" className="text-xs">
                                  Общий доступ
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {new Date(file.uploadedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {file.isOwn && file.sharedWith === 'none' && (
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button size="sm" variant="outline">
                                  <Share2 className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Поделиться файлом</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <p>Выберите, с кем поделиться файлом "{file.name}":</p>
                                  <div className="flex gap-2">
                                    <Button 
                                      onClick={() => shareFile(file.id, 'all')}
                                      className="flex-1"
                                    >
                                      Поделиться со всеми
                                    </Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                          )}
                          
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="ghost">
                                <Download className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
                              <DialogHeader>
                                <DialogTitle>{file.name}</DialogTitle>
                              </DialogHeader>
                              <div className="overflow-y-auto max-h-[60vh]">
                                <MarkdownFileViewer content={file.content} />
                              </div>
                            </DialogContent>
                          </Dialog>

                          {file.isOwn && (
                            <Button 
                              size="sm" 
                              variant="ghost"
                              onClick={() => deleteFile(file.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}