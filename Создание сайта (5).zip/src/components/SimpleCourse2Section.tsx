import { useState } from "react";
import { MarkdownFileViewer } from "./MarkdownFileViewer";

export function SimpleCourse2Section() {
  const [activeTab, setActiveTab] = useState("subjects");

  const subjects = [
    {
      id: "advanced-math",
      name: "Высшая математика",
      progress: 65,
      totalLessons: 28,
      completedLessons: 18,
      description: "Дифференциальные уравнения, ряды и интегральное исчисление",
      difficulty: "Высокая"
    },
    {
      id: "algorithms",
      name: "Алгоритмы и структуры данных",
      progress: 80,
      totalLessons: 32,
      completedLessons: 26,
      description: "Сложность алгоритмов, деревья, графы и динамическое программирование",
      difficulty: "Высокая"
    },
    {
      id: "databases",
      name: "Базы данных",
      progress: 70,
      totalLessons: 24,
      completedLessons: 17,
      description: "SQL, проектирование БД, нормализация и оптимизация запросов",
      difficulty: "Средняя"
    },
    {
      id: "web-dev",
      name: "Веб-разработка",
      progress: 55,
      totalLessons: 36,
      completedLessons: 20,
      description: "HTML, CSS, JavaScript, фреймворки и backend разработка",
      difficulty: "Средняя"
    }
  ];

  const projects = [
    {
      title: "Система управления библиотекой",
      subject: "Базы данных",
      type: "Курсовой проект",
      deadline: "15 декабря",
      status: "in-progress",
      description: "Разработка полноценной системы управления библиотекой с веб-интерфейсом"
    },
    {
      title: "Алгоритм сортировки с визуализацией",
      subject: "Алгоритмы",
      type: "Практический проект",
      deadline: "30 октября",
      status: "completed",
      description: "Реализация и визуализация различных алгоритмов сортировки"
    },
    {
      title: "Интернет-магазин",
      subject: "Веб-разработка",
      type: "Командный проект",
      deadline: "20 ноября",
      status: "pending",
      description: "Полнофункциональный интернет-магазин с корзиной и системой оплаты"
    }
  ];

  const achievements = [
    {
      title: "Отличник семестра",
      description: "Средний балл выше 4.5",
      earned: true
    },
    {
      title: "Лучший проект",
      description: "Проект получил наивысшую оценку",
      earned: true
    },
    {
      title: "Активный участник",
      description: "Участие во всех семинарах",
      earned: false
    }
  ];

  const upcomingExams = [
    {
      subject: "Высшая математика",
      date: "5 декабря",
      type: "Экзамен",
      duration: "3 часа"
    },
    {
      subject: "Алгоритмы и структуры данных",
      date: "10 декабря",
      type: "Экзамен",
      duration: "2.5 часа"
    },
    {
      subject: "Базы данных",
      date: "15 декабря",
      type: "Зачет",
      duration: "1.5 часа"
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Высокая': return 'bg-red-100 text-red-800';
      case 'Средняя': return 'bg-yellow-100 text-yellow-800';
      case 'Низкая': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'completed': return { label: "✅ Завершено", color: "bg-green-100 text-green-800" };
      case 'in-progress': return { label: "🕒 В работе", color: "bg-yellow-100 text-yellow-800" };
      case 'pending': return { label: "⏳ Ожидает", color: "bg-gray-100 text-gray-800" };
      default: return { label: status, color: "bg-gray-100 text-gray-800" };
    }
  };

  const tabs = [
    { id: "subjects", label: "Предметы" },
    { id: "projects", label: "Проекты" },
    { id: "exams", label: "Экзамены" },
    { id: "achievements", label: "Достижения" },
    { id: "markdown", label: "Загрузить .md" }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-gray-100">2 курс</h1>
        <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
          Углубленное изучение специальных дисциплин и работа над проектами
        </p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="flex space-x-8 px-4 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                activeTab === tab.id
                  ? "border-blue-500 text-blue-600 dark:text-blue-400"
                  : "border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600"
              }`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === "subjects" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-4">
          {subjects.map((subject) => (
            <div key={subject.id} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-xl font-semibold text-gray-900">{subject.name}</h3>
                <span className={`px-2 py-1 rounded-full text-xs ${getDifficultyColor(subject.difficulty)}`}>
                  {subject.difficulty}
                </span>
              </div>
              <p className="text-gray-600 text-sm mb-4">{subject.description}</p>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Прогресс</span>
                  <span className="text-sm font-medium">{subject.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full" 
                    style={{ width: `${subject.progress}%` }}
                  ></div>
                </div>
                <div className="flex justify-between items-center text-sm text-gray-600">
                  <span>{subject.completedLessons} из {subject.totalLessons} занятий</span>
                  <span>📈</span>
                </div>
                <button className="w-full py-2 px-4 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors">
                  Перейти к предмету
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === "projects" && (
        <div className="space-y-4 px-4">
          <h2 className="text-xl font-semibold text-gray-900">Курсовые и практические проекты</h2>
          {projects.map((project, index) => {
            const statusInfo = getStatusInfo(project.status);
            return (
              <div key={index} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{project.title}</h3>
                    <p className="text-sm text-gray-600">{project.subject} • {project.type}</p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs ${statusInfo.color}`}>
                    {statusInfo.label}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mb-4">{project.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-700">Срок сдачи: {project.deadline}</span>
                  <button className="py-1 px-3 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700">
                    Открыть проект
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {activeTab === "exams" && (
        <div className="space-y-4 px-4">
          <h2 className="text-xl font-semibold text-gray-900">Предстоящие экзамены</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcomingExams.map((exam, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{exam.subject}</h3>
                <span className={`inline-block px-2 py-1 rounded-full text-xs mb-4 ${
                  exam.type === 'Экзамен' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'
                }`}>
                  {exam.type}
                </span>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Дата</span>
                    <span className="font-medium">{exam.date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Продолжительность</span>
                    <span className="font-medium">{exam.duration}</span>
                  </div>
                  <button className="w-full mt-4 py-2 px-4 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors">
                    Подготовиться
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === "achievements" && (
        <div className="space-y-4 px-4">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Достижения и награды</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {achievements.map((achievement, index) => (
              <div key={index} className={`rounded-lg shadow-md p-6 text-center ${
                achievement.earned ? "bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800" : "bg-white dark:bg-gray-800"
              }`}>
                <div className={`text-4xl mb-2 ${achievement.earned ? 'text-yellow-500' : 'text-gray-400'}`}>
                  {achievement.earned ? '⭐' : '☆'}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">{achievement.title}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">{achievement.description}</p>
                <span className={`inline-block px-2 py-1 rounded-full text-xs ${
                  achievement.earned ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400' : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                }`}>
                  {achievement.earned ? "Получено" : "Не получено"}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === "markdown" && (
        <div className="px-4">
          <MarkdownFileViewer />
        </div>
      )}
    </div>
  );
}