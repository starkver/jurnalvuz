export function SimpleHomeSection() {
  const features = [
    {
      title: "Образовательные материалы",
      description: "Полный набор учебных материалов для 1 и 2 курса",
      icon: "📚"
    },
  
    {
      title: "In Development",
      description: "In Development",
      icon: "🏆"
    },
    {
      title: "Расписание",
      description: "Актуальное расписание занятий и экзаменов",
      icon: "📅"
    }
  ];

  const announcements = [
    {
      title: "Начало нового семестра",
      date: "15 сентября 2024",
      description: "Добро пожаловать в новый учебный семестр! Ознакомьтесь с обновленными материалами курса.",
      badge: "Важно"
    },
    {
      title: "Обновление материалов 1 курса",
      date: "10 сентября 2024",
      description: "Добавлены новые лекции и практические задания для первого курса.",
      badge: "Обновление"
    },
    {
      title: "Экзаменационная сессия",
      date: "1 декабря 2024",
      description: "Подготовка к зимней экзаменационной сессии. Расписание экзаменов доступно в разделе курсов.",
      badge: "Экзамены"
    }
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="text-center py-12 px-4">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 text-gray-900 dark:text-gray-100">
          Добро пожаловать в
          <span className="text-blue-600 dark:text-blue-400 block">Образовательный портал</span>
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto mb-8">
          Ваш путь к знаниям начинается здесь. Изучайте материалы курсов, 
          отслеживайте прогресс и достигайте новых высот в образовании.
        </p>
      </section>

      {/* Features Grid */}
      <section className="px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 justify-items-center">
          {features.map((feature, index) => (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 w-full max-w-sm">
              <div className="text-center">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-lg font-semibold mb-2 text-gray-900 dark:text-gray-100">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Announcements */}
      <section className="px-4">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-gray-100">Объявления</h2>
        <div className="space-y-4">
          {announcements.map((announcement, index) => (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <div className="flex justify-between items-start flex-wrap gap-2 mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">{announcement.title}</h3>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs rounded-full">
                    {announcement.badge}
                  </span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">{announcement.date}</span>
                </div>
              </div>
              <p className="text-gray-600 dark:text-gray-300">{announcement.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Quick Stats */}
      <section className="bg-gray-50 dark:bg-gray-800 rounded-lg p-8 mx-4">
        <h2 className="text-2xl font-bold text-center mb-8 text-gray-900 dark:text-gray-100">Статистика портала</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">150+</div>
            <div className="text-gray-600 dark:text-gray-300">Студентов</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">25</div>
            <div className="text-gray-600 dark:text-gray-300">Предметов</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">500+</div>
            <div className="text-gray-600 dark:text-gray-300">Материалов</div>
          </div>
        </div>
      </section>
    </div>
  );
}