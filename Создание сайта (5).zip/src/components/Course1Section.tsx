import { useState, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { BookOpen, FileText, Video, Download, Clock, CheckCircle, Upload, Share2, Trash2 } from "lucide-react";
import { MarkdownFileViewer } from "./MarkdownFileViewer";
import { useAuth } from "./AuthContext";

interface UserFile {
  id: string;
  name: string;
  content: string;
  uploadedAt: string;
  sharedWith: 'none' | 'all' | 'specific';
  sharedBy?: string;
}

export function Course1Section() {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [userFiles, setUserFiles] = useState<UserFile[]>(() => {
    const saved = localStorage.getItem(`course1_files_${user?.id}`);
    return saved ? JSON.parse(saved) : [];
  });
  const [sharedFiles, setSharedFiles] = useState<UserFile[]>(() => {
    const saved = localStorage.getItem('course1_shared_files');
    return saved ? JSON.parse(saved) : [];
  });

  const subjects = [
    {
      id: "anatomy",
      name: "Анатомия человека",
      progress: 75,
      totalLessons: 24,
      completedLessons: 18,
      description: "Изучение строения человеческого тела и органов"
    },
    {
      id: "histology",
      name: "Гистология",
      progress: 60,
      totalLessons: 20,
      completedLessons: 12,
      description: "Микроскопическое строение тканей и клеток"
    },
    {
      id: "physiology",
      name: "Физиология", 
      progress: 85,
      totalLessons: 22,
      completedLessons: 18,
      description: "Функционирование систем организма человека"
    },
    {
      id: "chemistry",
      name: "Медицинская химия",
      progress: 70,
      totalLessons: 18,
      completedLessons: 13,
      description: "Основы химии в медицинском контексте"
    }
  ];

  const saveUserFiles = (files: UserFile[]) => {
    setUserFiles(files);
    localStorage.setItem(`course1_files_${user?.id}`, JSON.stringify(files));
  };

  const saveSharedFiles = (files: UserFile[]) => {
    setSharedFiles(files);
    localStorage.setItem('course1_shared_files', JSON.stringify(files));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.name.endsWith('.md')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        const newFile: UserFile = {
          id: Date.now().toString(),
          name: file.name,
          content,
          uploadedAt: new Date().toISOString(),
          sharedWith: 'none'
        };
        saveUserFiles([...userFiles, newFile]);
      };
      reader.readAsText(file);
    }
  };

  const shareFile = (fileId: string, shareType: 'all' | 'specific') => {
    const file = userFiles.find(f => f.id === fileId);
    if (file && shareType === 'all') {
      const sharedFile: UserFile = {
        ...file,
        sharedWith: 'all',
        sharedBy: user?.username
      };
      saveSharedFiles([...sharedFiles, sharedFile]);
      
      const updatedUserFiles = userFiles.map(f => 
        f.id === fileId ? { ...f, sharedWith: 'all' } : f
      );
      saveUserFiles(updatedUserFiles);
    }
  };

  const deleteFile = (fileId: string) => {
    const updatedFiles = userFiles.filter(f => f.id !== fileId);
    saveUserFiles(updatedFiles);
  };

  const allFiles = [
    ...userFiles.map(f => ({ ...f, isOwn: true })),
    ...sharedFiles.filter(f => !userFiles.some(uf => uf.name === f.name))
      .map(f => ({ ...f, isOwn: false }))
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'video': return <Video className="h-4 w-4" />;
      case 'file': return <FileText className="h-4 w-4" />;
      case 'document': return <BookOpen className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">1 курс - Медицинские дисциплины</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Изучайте основные медицинские предметы первого курса, отслеживайте прогресс и работайте с материалами
        </p>
      </div>

      <Tabs defaultValue="subjects" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="subjects">Предметы</TabsTrigger>
          <TabsTrigger value="materials">Материалы</TabsTrigger>
          <TabsTrigger value="files">Мои файлы</TabsTrigger>
        </TabsList>

        <TabsContent value="subjects" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {subjects.map((subject) => (
              <Card key={subject.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">{subject.name}</CardTitle>
                      <CardDescription className="mt-2">{subject.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Прогресс</span>
                      <span className="text-sm font-medium">{subject.progress}%</span>
                    </div>
                    <Progress value={subject.progress} className="h-2" />
                  </div>
                  <div className="flex justify-between items-center text-sm text-muted-foreground">
                    <span>{subject.completedLessons} из {subject.totalLessons} занятий</span>
                  </div>
                  <Button className="w-full" variant="outline">
                    Перейти к предмету
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="materials" className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Учебные материалы</h2>
              <div className="flex gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept=".md"
                  style={{ display: 'none' }}
                />
                <Button onClick={() => fileInputRef.current?.click()}>
                  <Upload className="h-4 w-4 mr-2" />
                  Загрузить файл
                </Button>
              </div>
            </div>
            
            {allFiles.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 dark:text-gray-400 mb-2">
                    Файлы не найдены
                  </h3>
                  <p className="text-gray-500 dark:text-gray-500 mb-4">
                    Загрузите первый Markdown файл для начала работы
                  </p>
                  <Button onClick={() => fileInputRef.current?.click()}>
                    <Upload className="h-4 w-4 mr-2" />
                    Загрузить файл
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {allFiles.map((file) => (
                  <Card key={file.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4">
                          <div className="p-2 bg-primary/10 rounded-lg">
                            <FileText className="h-4 w-4" />
                          </div>
                          <div className="space-y-1">
                            <h3 className="font-medium">{file.name}</h3>
                            <div className="flex items-center space-x-2">
                              {file.sharedBy && (
                                <Badge variant="secondary" className="text-xs">
                                  Поделился: {file.sharedBy}
                                </Badge>
                              )}
                              {file.isOwn && file.sharedWith === 'all' && (
                                <Badge variant="outline" className="text-xs">
                                  Общий доступ
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {new Date(file.uploadedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {file.isOwn && file.sharedWith === 'none' && (
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button size="sm" variant="outline">
                                  <Share2 className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Поделиться файлом</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <p>Выберите, с кем поделиться файлом "{file.name}":</p>
                                  <div className="flex gap-2">
                                    <Button 
                                      onClick={() => shareFile(file.id, 'all')}
                                      className="flex-1"
                                    >
                                      Поделиться со всеми
                                    </Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                          )}
                          
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="ghost">
                                <Download className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
                              <DialogHeader>
                                <DialogTitle>{file.name}</DialogTitle>
                              </DialogHeader>
                              <div className="overflow-y-auto max-h-[60vh]">
                                <MarkdownFileViewer content={file.content} />
                              </div>
                            </DialogContent>
                          </Dialog>

                          {file.isOwn && (
                            <Button 
                              size="sm" 
                              variant="ghost"
                              onClick={() => deleteFile(file.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="files" className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Мои загруженные файлы</h2>
              <Button onClick={() => fileInputRef.current?.click()}>
                <Upload className="h-4 w-4 mr-2" />
                Загрузить файл
              </Button>
            </div>
            
            {userFiles.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 dark:text-gray-400 mb-2">
                    У вас нет загруженных файлов
                  </h3>
                  <p className="text-gray-500 dark:text-gray-500 mb-4">
                    Загрузите Markdown файлы для работы с материалами
                  </p>
                  <Button onClick={() => fileInputRef.current?.click()}>
                    <Upload className="h-4 w-4 mr-2" />
                    Загрузить первый файл
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {userFiles.map((file) => (
                  <Card key={file.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4">
                          <div className="p-2 bg-primary/10 rounded-lg">
                            <FileText className="h-4 w-4" />
                          </div>
                          <div className="space-y-1">
                            <h3 className="font-medium">{file.name}</h3>
                            <div className="flex items-center space-x-2">
                              {file.sharedWith === 'all' ? (
                                <Badge variant="default" className="text-xs">
                                  Общий доступ
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="text-xs">
                                  Личный файл
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              Загружен: {new Date(file.uploadedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {file.sharedWith === 'none' && (
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button size="sm" variant="outline">
                                  <Share2 className="h-4 w-4 mr-2" />
                                  Поделиться
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Поделиться файлом</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <p>Выберите, с кем поделиться файлом "{file.name}":</p>
                                  <div className="flex gap-2">
                                    <Button 
                                      onClick={() => shareFile(file.id, 'all')}
                                      className="flex-1"
                                    >
                                      Поделиться со всеми
                                    </Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                          )}
                          
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="ghost">
                                <BookOpen className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
                              <DialogHeader>
                                <DialogTitle>{file.name}</DialogTitle>
                              </DialogHeader>
                              <div className="overflow-y-auto max-h-[60vh]">
                                <MarkdownFileViewer content={file.content} />
                              </div>
                            </DialogContent>
                          </Dialog>

                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => deleteFile(file.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}